/*
  # Create Post Drafts Table for Auto-Save

  ## Overview
  This migration creates a table to store draft versions of blog posts, enabling auto-save functionality
  so writers never lose their work.

  ## New Tables

  ### `post_drafts` - Auto-saved post drafts
    - `id` (uuid, primary key) - Unique draft identifier
    - `user_id` (uuid, required) - Reference to the user creating the draft
    - `post_id` (uuid, optional) - Reference to existing post if editing
    - `title` (text) - Draft post title
    - `content` (text) - Draft post content
    - `excerpt` (text) - Draft post excerpt
    - `category_id` (uuid) - Draft category selection
    - `image_url` (text) - Draft featured image URL
    - `published` (boolean) - Draft publish status
    - `created_at` (timestamptz) - When the draft was first created
    - `updated_at` (timestamptz) - When the draft was last auto-saved

  ## Security

  ### RLS Policies
    - Users can only view their own drafts
    - Users can create their own drafts
    - Users can update their own drafts
    - Users can delete their own drafts

  ## Notes
    - Drafts are automatically saved every 10 seconds while editing
    - When a post is published, the corresponding draft can be deleted
    - Each user-post combination should have at most one draft
*/

CREATE TABLE IF NOT EXISTS post_drafts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE,
  title text DEFAULT '',
  content text DEFAULT '',
  excerpt text DEFAULT '',
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  image_url text DEFAULT '',
  published boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_post_drafts_user_id ON post_drafts(user_id);
CREATE INDEX IF NOT EXISTS idx_post_drafts_post_id ON post_drafts(post_id);

-- Enable RLS
ALTER TABLE post_drafts ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own drafts"
  ON post_drafts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own drafts"
  ON post_drafts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own drafts"
  ON post_drafts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own drafts"
  ON post_drafts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);