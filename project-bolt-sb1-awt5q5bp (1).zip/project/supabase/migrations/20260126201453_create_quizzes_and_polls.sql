/*
  # Interactive Blog Elements - Quizzes and Polls

  1. New Tables
    - `post_quizzes` - Quiz definitions linked to posts
      - `id` (uuid, primary key)
      - `post_id` (uuid, foreign key to posts)
      - `title` (text) - Quiz title/name
      - `description` (text) - Optional quiz description
      - `created_at` (timestamptz)
    
    - `quiz_questions` - Questions within a quiz
      - `id` (uuid, primary key)
      - `quiz_id` (uuid, foreign key to post_quizzes)
      - `question_text` (text) - The question
      - `order_index` (integer) - Question order
      - `created_at` (timestamptz)
    
    - `quiz_options` - Answer options for questions
      - `id` (uuid, primary key)
      - `question_id` (uuid, foreign key to quiz_questions)
      - `option_text` (text) - The answer option
      - `is_correct` (boolean) - Whether this is the correct answer
      - `order_index` (integer) - Option order
    
    - `quiz_responses` - User responses to quizzes
      - `id` (uuid, primary key)
      - `quiz_id` (uuid, foreign key to post_quizzes)
      - `session_id` (text) - Anonymous session tracking
      - `score` (integer) - Number of correct answers
      - `total_questions` (integer) - Total questions answered
      - `created_at` (timestamptz)
    
    - `post_polls` - Poll definitions linked to posts
      - `id` (uuid, primary key)
      - `post_id` (uuid, foreign key to posts)
      - `question` (text) - Poll question
      - `allow_multiple` (boolean) - Allow multiple selections
      - `created_at` (timestamptz)
    
    - `poll_options` - Options for polls
      - `id` (uuid, primary key)
      - `poll_id` (uuid, foreign key to post_polls)
      - `option_text` (text) - The option text
      - `order_index` (integer) - Option order
    
    - `poll_votes` - User votes on polls
      - `id` (uuid, primary key)
      - `poll_id` (uuid, foreign key to post_polls)
      - `option_id` (uuid, foreign key to poll_options)
      - `session_id` (text) - Anonymous session tracking
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Public read access for published content
    - Authenticated users can manage their own quizzes/polls
    - Anyone can submit responses/votes (anonymous)
*/

-- Post Quizzes
CREATE TABLE IF NOT EXISTS post_quizzes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE post_quizzes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view quizzes for published posts"
  ON post_quizzes FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_quizzes.post_id
      AND posts.published = true
    )
  );

CREATE POLICY "Post owners can manage their quizzes"
  ON post_quizzes FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_quizzes.post_id
      AND posts.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_quizzes.post_id
      AND posts.user_id = auth.uid()
    )
  );

-- Quiz Questions
CREATE TABLE IF NOT EXISTS quiz_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id uuid NOT NULL REFERENCES post_quizzes(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  order_index integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE quiz_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view questions for published posts"
  ON quiz_questions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM post_quizzes
      JOIN posts ON posts.id = post_quizzes.post_id
      WHERE post_quizzes.id = quiz_questions.quiz_id
      AND posts.published = true
    )
  );

CREATE POLICY "Post owners can manage their quiz questions"
  ON quiz_questions FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM post_quizzes
      JOIN posts ON posts.id = post_quizzes.post_id
      WHERE post_quizzes.id = quiz_questions.quiz_id
      AND posts.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM post_quizzes
      JOIN posts ON posts.id = post_quizzes.post_id
      WHERE post_quizzes.id = quiz_questions.quiz_id
      AND posts.user_id = auth.uid()
    )
  );

-- Quiz Options
CREATE TABLE IF NOT EXISTS quiz_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES quiz_questions(id) ON DELETE CASCADE,
  option_text text NOT NULL,
  is_correct boolean NOT NULL DEFAULT false,
  order_index integer NOT NULL DEFAULT 0
);

ALTER TABLE quiz_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view options for published posts"
  ON quiz_options FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM quiz_questions
      JOIN post_quizzes ON post_quizzes.id = quiz_questions.quiz_id
      JOIN posts ON posts.id = post_quizzes.post_id
      WHERE quiz_questions.id = quiz_options.question_id
      AND posts.published = true
    )
  );

CREATE POLICY "Post owners can manage their quiz options"
  ON quiz_options FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM quiz_questions
      JOIN post_quizzes ON post_quizzes.id = quiz_questions.quiz_id
      JOIN posts ON posts.id = post_quizzes.post_id
      WHERE quiz_questions.id = quiz_options.question_id
      AND posts.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM quiz_questions
      JOIN post_quizzes ON post_quizzes.id = quiz_questions.quiz_id
      JOIN posts ON posts.id = post_quizzes.post_id
      WHERE quiz_questions.id = quiz_options.question_id
      AND posts.user_id = auth.uid()
    )
  );

-- Quiz Responses
CREATE TABLE IF NOT EXISTS quiz_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  quiz_id uuid NOT NULL REFERENCES post_quizzes(id) ON DELETE CASCADE,
  session_id text NOT NULL,
  score integer NOT NULL DEFAULT 0,
  total_questions integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE quiz_responses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert quiz responses"
  ON quiz_responses FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can view their own responses"
  ON quiz_responses FOR SELECT
  USING (session_id = session_id);

-- Post Polls
CREATE TABLE IF NOT EXISTS post_polls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  question text NOT NULL,
  allow_multiple boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE post_polls ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view polls for published posts"
  ON post_polls FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_polls.post_id
      AND posts.published = true
    )
  );

CREATE POLICY "Post owners can manage their polls"
  ON post_polls FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_polls.post_id
      AND posts.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM posts
      WHERE posts.id = post_polls.post_id
      AND posts.user_id = auth.uid()
    )
  );

-- Poll Options
CREATE TABLE IF NOT EXISTS poll_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL REFERENCES post_polls(id) ON DELETE CASCADE,
  option_text text NOT NULL,
  order_index integer NOT NULL DEFAULT 0
);

ALTER TABLE poll_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view poll options for published posts"
  ON poll_options FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM post_polls
      JOIN posts ON posts.id = post_polls.post_id
      WHERE post_polls.id = poll_options.poll_id
      AND posts.published = true
    )
  );

CREATE POLICY "Post owners can manage their poll options"
  ON poll_options FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM post_polls
      JOIN posts ON posts.id = post_polls.post_id
      WHERE post_polls.id = poll_options.poll_id
      AND posts.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM post_polls
      JOIN posts ON posts.id = post_polls.post_id
      WHERE post_polls.id = poll_options.poll_id
      AND posts.user_id = auth.uid()
    )
  );

-- Poll Votes
CREATE TABLE IF NOT EXISTS poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL REFERENCES post_polls(id) ON DELETE CASCADE,
  option_id uuid NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
  session_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(poll_id, option_id, session_id)
);

ALTER TABLE poll_votes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert poll votes"
  ON poll_votes FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view vote counts"
  ON poll_votes FOR SELECT
  USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_post_quizzes_post_id ON post_quizzes(post_id);
CREATE INDEX IF NOT EXISTS idx_quiz_questions_quiz_id ON quiz_questions(quiz_id);
CREATE INDEX IF NOT EXISTS idx_quiz_options_question_id ON quiz_options(question_id);
CREATE INDEX IF NOT EXISTS idx_quiz_responses_quiz_id ON quiz_responses(quiz_id);
CREATE INDEX IF NOT EXISTS idx_post_polls_post_id ON post_polls(post_id);
CREATE INDEX IF NOT EXISTS idx_poll_options_poll_id ON poll_options(poll_id);
CREATE INDEX IF NOT EXISTS idx_poll_votes_poll_id ON poll_votes(poll_id);
CREATE INDEX IF NOT EXISTS idx_poll_votes_option_id ON poll_votes(option_id);