/*
  # Add Admin Role System

  1. Overview
    - Implements admin role system using Supabase auth metadata
    - Restricts post creation/editing to admin users only
    - Public can still read published posts
  
  2. Changes
    - Create helper function to check if user is admin
    - Create function to set user as admin (for initial setup)
    - Update RLS policies on posts table:
      - Anyone can read published posts
      - Only admins can insert posts
      - Only admins can update their own posts
      - Only admins can delete their own posts
  
  3. Security
    - Admin status stored in auth.users raw_app_meta_data (cannot be modified by users)
    - RLS policies enforce admin-only access for write operations
    - Regular users cannot bypass these restrictions
  
  4. Setup Instructions
    After migration, run this SQL to make your first user an admin:
    ```sql
    SELECT set_user_admin('your-email@example.com');
    ```
*/

-- Create function to check if current user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN COALESCE(
    (SELECT (auth.jwt()->>'app_metadata')::jsonb->>'is_admin')::boolean,
    false
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to set a user as admin (only accessible via SQL)
CREATE OR REPLACE FUNCTION set_user_admin(user_email text)
RETURNS void AS $$
DECLARE
  user_id uuid;
BEGIN
  -- Get user ID from email
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = user_email;
  
  IF user_id IS NULL THEN
    RAISE EXCEPTION 'User with email % not found', user_email;
  END IF;
  
  -- Update user metadata to set admin flag
  UPDATE auth.users
  SET raw_app_meta_data = 
    COALESCE(raw_app_meta_data, '{}'::jsonb) || '{"is_admin": true}'::jsonb
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view published posts" ON posts;
DROP POLICY IF EXISTS "Users can insert own posts" ON posts;
DROP POLICY IF EXISTS "Users can update own posts" ON posts;
DROP POLICY IF EXISTS "Users can delete own posts" ON posts;

-- Create new RLS policies for admin-only access

-- Anyone can read published posts
CREATE POLICY "Anyone can view published posts"
  ON posts
  FOR SELECT
  USING (published = true);

-- Only admins can insert posts
CREATE POLICY "Admins can insert posts"
  ON posts
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

-- Only admins can update their own posts
CREATE POLICY "Admins can update own posts"
  ON posts
  FOR UPDATE
  TO authenticated
  USING (is_admin() AND auth.uid() = user_id)
  WITH CHECK (is_admin() AND auth.uid() = user_id);

-- Only admins can delete their own posts
CREATE POLICY "Admins can delete own posts"
  ON posts
  FOR DELETE
  TO authenticated
  USING (is_admin() AND auth.uid() = user_id);

-- Admin users can also view their own draft posts
CREATE POLICY "Admins can view own draft posts"
  ON posts
  FOR SELECT
  TO authenticated
  USING (is_admin() AND auth.uid() = user_id);