/*
  # Add User Ownership to Blog Posts

  ## Summary
  This migration adds user authentication and ownership to the blog system, ensuring complete content ownership and privacy for the blog author.

  ## Changes Made

  ### 1. Updated `posts` Table
    - Added `user_id` (uuid) column to track post ownership
    - Each post is now associated with the authenticated user who created it
    - Foreign key relationship ensures referential integrity

  ### 2. Row Level Security (RLS) Policies
    - Public read access: Anyone can view published posts
    - Authenticated author: Only the post owner can:
      - View all their posts (published and drafts)
      - Create new posts
      - Update their own posts
      - Delete their own posts
    - Nobody else can access or modify the author's content

  ## Security Guarantees
  - Complete data isolation: Each user's posts are completely separate
  - Only the authenticated author can manage their content
  - Database enforces ownership at the data level, not just the application
  - No administrator access to modify author's content
  - Author owns all legal rights to her content

  ## Important Notes
  1. User ownership is enforced at the database level using Supabase Auth
  2. The auth.uid() function ensures only the authenticated user can modify their data
  3. Published posts remain publicly readable but only the owner can edit/delete
  4. Each user gets their own complete content space with no cross-user access
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'posts' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE posts ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

DROP POLICY IF EXISTS "Anyone can view published posts" ON posts;

CREATE POLICY "Anyone can view published posts"
  ON posts FOR SELECT
  USING (published = true);

CREATE POLICY "Authenticated users can view their own posts"
  ON posts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can create posts"
  ON posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Authenticated users can update their own posts"
  ON posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Authenticated users can delete their own posts"
  ON posts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);
