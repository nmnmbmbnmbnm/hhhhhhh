/*
  # Create Blog Images Storage Bucket

  1. New Storage
    - `blog-images` bucket for storing uploaded blog post images
    - Public bucket so images can be accessed without authentication
  
  2. Security
    - Allow authenticated users to upload images
    - Allow authenticated users to update their own images
    - Allow authenticated users to delete their own images
    - Allow public read access to all images
*/

-- Create the storage bucket for blog images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'blog-images',
  'blog-images',
  true,
  5242880, -- 5MB limit
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload images
CREATE POLICY "Authenticated users can upload blog images"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'blog-images');

-- Allow authenticated users to update their own uploaded images
CREATE POLICY "Users can update their own blog images"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'blog-images' AND owner::uuid = auth.uid())
  WITH CHECK (bucket_id = 'blog-images' AND owner::uuid = auth.uid());

-- Allow authenticated users to delete their own uploaded images
CREATE POLICY "Users can delete their own blog images"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'blog-images' AND owner::uuid = auth.uid());

-- Allow public read access to all blog images
CREATE POLICY "Public read access to blog images"
  ON storage.objects
  FOR SELECT
  TO public
  USING (bucket_id = 'blog-images');