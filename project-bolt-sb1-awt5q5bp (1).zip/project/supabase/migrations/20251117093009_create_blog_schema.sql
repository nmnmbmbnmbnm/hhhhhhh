/*
  # Blog Website Schema

  ## Overview
  This migration creates the database structure for a topic-based blog website.
  
  ## New Tables
  
  ### 1. `categories` - Blog topic categories
    - `id` (uuid, primary key) - Unique category identifier
    - `name` (text, unique) - Category name (e.g., "Fashion", "Beauty", "Lifestyle")
    - `slug` (text, unique) - URL-friendly version of the name
    - `description` (text) - Brief description of the category
    - `created_at` (timestamptz) - When the category was created
  
  ### 2. `posts` - Individual blog posts
    - `id` (uuid, primary key) - Unique post identifier
    - `title` (text) - Post title
    - `slug` (text, unique) - URL-friendly version of the title
    - `content` (text) - Full blog post content
    - `excerpt` (text) - Short preview of the post
    - `category_id` (uuid) - Reference to the category
    - `image_url` (text) - Featured image URL
    - `published` (boolean) - Whether the post is published
    - `published_at` (timestamptz) - When the post was published
    - `created_at` (timestamptz) - When the post was created
    - `updated_at` (timestamptz) - When the post was last updated
  
  ## Security
  
  ### RLS Policies
  - Public read access for published posts and all categories
  - No public write access (you'll manage content separately)
  
  ## Notes
  - All posts are linked to categories for topic-based organization
  - Posts can be drafted (unpublished) before going live
  - Timestamps track creation and publication dates
*/

CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  content text NOT NULL,
  excerpt text DEFAULT '',
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  image_url text DEFAULT '',
  published boolean DEFAULT false,
  published_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view categories"
  ON categories FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view published posts"
  ON posts FOR SELECT
  USING (published = true);