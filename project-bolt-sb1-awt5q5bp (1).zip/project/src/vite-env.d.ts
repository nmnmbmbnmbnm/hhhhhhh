/// <reference types="vite/client" />

interface Window {
  PinUtils?: {
    build: () => void;
  };
}
