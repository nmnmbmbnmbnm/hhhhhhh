import Header from '../components/Header';
import Footer from '../components/Footer';

export default function AffiliateDisclaimer() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-pink-50/30 to-rose-50/40">
      <Header />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg p-8 sm:p-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">Affiliate Disclaimer</h1>
          <p className="text-sm text-gray-500 mb-8">Last Updated: January 26, 2026</p>

          <div className="prose prose-pink max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Introduction</h2>
              <p className="text-gray-700 leading-relaxed">
                This Affiliate Disclaimer applies to the website Womanthoughts ("Website") and discloses
                the nature of affiliate relationships with third-party companies. This page is designed
                to inform you that we may receive compensation when you click on links to products or
                services and subsequently make a purchase.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Affiliate Partnerships</h2>
              <p className="text-gray-700 leading-relaxed">
                Womanthoughts participates in various affiliate marketing programs. This means that we may
                earn commissions on products or services purchased through links on our website. These
                affiliate programs are designed to provide a means for websites to earn advertising fees
                by advertising and linking to partner websites.
              </p>
              <p className="text-gray-700 leading-relaxed mt-3">
                We are a participant in affiliate programs including, but not limited to, Amazon Associates
                and other reputable affiliate networks. When you click on an affiliate link and make a
                purchase, we may receive a small commission at no additional cost to you.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Commitment to Transparency</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                We believe in full transparency with our readers. Here's what you should know:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li><strong>No Additional Cost:</strong> Using our affiliate links does not increase the price you pay for products or services.</li>
                <li><strong>Honest Reviews:</strong> Our opinions and reviews are always our own and are not influenced by affiliate partnerships.</li>
                <li><strong>Genuine Recommendations:</strong> We only recommend products and services we believe will add value to our readers.</li>
                <li><strong>Clear Disclosure:</strong> We strive to clearly disclose affiliate relationships where applicable.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">How Affiliate Links Work</h2>
              <p className="text-gray-700 leading-relaxed">
                When you click on an affiliate link on our website and make a purchase, the company whose
                product or service you purchased may pay us a referral commission. This commission is paid
                by the company, not by you, and does not affect the price you pay.
              </p>
              <p className="text-gray-700 leading-relaxed mt-3">
                These commissions help support our website and allow us to continue creating quality content
                for our readers. We appreciate your support when you choose to purchase through our affiliate links.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Editorial Independence</h2>
              <p className="text-gray-700 leading-relaxed">
                Our editorial content is created independently of our affiliate partnerships. We maintain
                complete editorial freedom and do not allow affiliate relationships to influence our content,
                recommendations, or opinions. Our primary commitment is to provide valuable, honest, and
                helpful information to our readers.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Product Reviews and Recommendations</h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                When we review products or make recommendations:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>We share our genuine opinions based on research, testing, or personal experience</li>
                <li>We highlight both positive and negative aspects of products</li>
                <li>We consider factors such as quality, value, functionality, and user experience</li>
                <li>We aim to provide comprehensive information to help you make informed decisions</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Your Responsibility</h2>
              <p className="text-gray-700 leading-relaxed">
                While we strive to provide accurate and helpful information, we encourage you to conduct
                your own research before making any purchase decisions. Product features, pricing, and
                availability may change over time. We recommend verifying all information directly with
                the merchant before making a purchase.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Updates to This Disclaimer</h2>
              <p className="text-gray-700 leading-relaxed">
                We may update this Affiliate Disclaimer from time to time to reflect changes in our practices
                or for other operational, legal, or regulatory reasons. We will notify you of any material
                changes by posting the updated disclaimer on this page and updating the "Last Updated" date.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Questions</h2>
              <p className="text-gray-700 leading-relaxed">
                If you have any questions about our affiliate relationships or this disclaimer, please
                feel free to contact us at:
              </p>
              <p className="text-gray-700 leading-relaxed mt-3">
                Email: <a href="mailto:womanthoughts.contact@gmail.com" className="text-pink-500 hover:text-pink-600 underline">womanthoughts.contact@gmail.com</a>
              </p>
            </section>

            <section className="bg-pink-50/50 rounded-xl p-6 border border-pink-100">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Thank You</h2>
              <p className="text-gray-700 leading-relaxed">
                Thank you for supporting Womanthoughts. When you purchase through our affiliate links,
                you help us continue creating valuable content while discovering products and services
                that may enhance your life. We appreciate your trust and readership.
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
