import { Heart, Sparkles, Camera, Coffee } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50">
      <Header />

      <main className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="h-64 bg-gradient-to-r from-pink-400 via-rose-400 to-pink-300 relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-white">
                <h1 className="text-5xl font-bold mb-4">About Me</h1>
                <p className="text-xl opacity-90">Beauty, Lifestyle & Everything In Between</p>
              </div>
            </div>
          </div>

          <div className="p-8 md:p-12">
            <div className="prose prose-pink max-w-none">
              <div className="flex items-center gap-3 mb-8">
                <Sparkles className="text-pink-400" size={32} />
                <h2 className="text-3xl font-bold text-gray-800 m-0">Hello, Beautiful!</h2>
              </div>

              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                Welcome to my little corner of the internet! I'm so glad you're here. Womanthoughts is where I share my passion for all things beauty and lifestyle – from skincare routines that actually work to the little moments that make life magical.
              </p>

              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                I believe that beauty isn't just about what you put on your face – it's about how you live your life, the confidence you carry, and the joy you find in the everyday. Whether it's discovering a new lipstick shade that makes you feel unstoppable or creating a morning routine that sets the tone for your entire day, I'm here to share it all with you.
              </p>

              <div className="grid md:grid-cols-2 gap-6 my-10">
                <div className="bg-pink-50 p-6 rounded-xl">
                  <div className="flex items-center gap-3 mb-3">
                    <Heart className="text-pink-400" size={24} />
                    <h3 className="text-xl font-semibold text-gray-800 m-0">My Passion</h3>
                  </div>
                  <p className="text-gray-700 m-0">
                    Beauty products, skincare science, and helping women feel confident in their own skin.
                  </p>
                </div>

                <div className="bg-rose-50 p-6 rounded-xl">
                  <div className="flex items-center gap-3 mb-3">
                    <Camera className="text-rose-400" size={24} />
                    <h3 className="text-xl font-semibold text-gray-800 m-0">My Style</h3>
                  </div>
                  <p className="text-gray-700 m-0">
                    Authentic, relatable, and always keeping it real. No filters on life – just honest reviews and genuine experiences.
                  </p>
                </div>

                <div className="bg-pink-50 p-6 rounded-xl">
                  <div className="flex items-center gap-3 mb-3">
                    <Coffee className="text-pink-400" size={24} />
                    <h3 className="text-xl font-semibold text-gray-800 m-0">My Lifestyle</h3>
                  </div>
                  <p className="text-gray-700 m-0">
                    Coffee enthusiast, self-care advocate, and believer that small moments of beauty make life extraordinary.
                  </p>
                </div>

                <div className="bg-rose-50 p-6 rounded-xl">
                  <div className="flex items-center gap-3 mb-3">
                    <Sparkles className="text-rose-400" size={24} />
                    <h3 className="text-xl font-semibold text-gray-800 m-0">My Mission</h3>
                  </div>
                  <p className="text-gray-700 m-0">
                    To inspire women to embrace their unique beauty and create lives they absolutely love.
                  </p>
                </div>
              </div>

              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                When I'm not testing the latest beauty products or writing about wellness trends, you'll find me exploring new cafes, curating the perfect playlist, or planning my next adventure. Life is too short for boring routines and mediocre mascara!
              </p>

              <div className="bg-gradient-to-r from-pink-100 to-rose-100 p-8 rounded-xl my-8 text-center">
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Let's Connect</h3>
                <p className="text-gray-700 mb-6">
                  I love hearing from fellow beauty and lifestyle enthusiasts! Whether you have a question about a product, want to share your own experiences, or just want to say hi – I'm all ears.
                </p>
                <a
                  href="mailto:womanthoughts.contact@gmail.com"
                  className="inline-block text-pink-600 hover:text-rose-600 font-semibold text-lg mb-4 transition-colors"
                >
                  womanthoughts.contact@gmail.com
                </a>
                <p className="text-pink-600 font-semibold text-lg">
                  Thank you for being part of this beautiful journey!
                </p>
              </div>

              <p className="text-lg text-gray-700 leading-relaxed">
                Here's to living beautifully, loving fully, and never settling for anything less than extraordinary.
              </p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
