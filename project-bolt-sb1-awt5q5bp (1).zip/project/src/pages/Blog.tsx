import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronRight, Calendar, Tag } from 'lucide-react';
import { supabase, Post, Category } from '../lib/supabase';
import Header from '../components/Header';
import Footer from '../components/Footer';
import BlogPost from '../components/BlogPost';

export default function Blog() {
  const { postId } = useParams();
  const navigate = useNavigate();
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (postId && posts.length > 0) {
      const post = posts.find(p => p.id === postId);
      if (post) {
        setSelectedPost(post);
      }
    } else {
      setSelectedPost(null);
    }
  }, [postId, posts]);

  const fetchData = async () => {
    setLoading(true);

    const [postsResponse, categoriesResponse] = await Promise.all([
      supabase
        .from('posts')
        .select('*')
        .eq('published', true)
        .order('published_at', { ascending: false }),
      supabase
        .from('categories')
        .select('*')
        .order('name')
    ]);

    if (postsResponse.data) setPosts(postsResponse.data);
    if (categoriesResponse.data) setCategories(categoriesResponse.data);

    setLoading(false);
  };

  const getCategoryById = (categoryId: string | null) => {
    return categories.find((cat) => cat.id === categoryId) || null;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  if (selectedPost) {
    return (
      <>
        <Header />
        <BlogPost post={selectedPost} onBack={() => navigate('/blog')} />
        <Footer />
      </>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50">
        <Header />
        <div className="flex items-center justify-center min-h-[70vh]">
          <div className="text-center">
            <div className="relative inline-block">
              <div className="absolute inset-0 bg-pink-300/20 rounded-full blur-xl"></div>
              <div className="relative w-16 h-16 border-4 border-pink-400 border-t-transparent rounded-full animate-spin"></div>
            </div>
            <p className="mt-4 text-gray-600 font-light">Loading stories...</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50">
        <Header />
        <div className="flex items-center justify-center min-h-[70vh]">
          <div className="text-center">
            <p className="text-xl text-gray-600 font-light">No stories yet. Check back soon!</p>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50">
      <Header />

      <main className="container mx-auto px-4 py-12 max-w-7xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-4">
            Explore <span className="bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 bg-clip-text text-transparent">Stories</span>
          </h1>
          <div className="w-24 h-0.5 bg-gradient-to-r from-transparent via-pink-300 to-transparent mx-auto mb-4"></div>
          <p className="text-gray-600 font-light">Discover all our stories in one place</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => {
            const category = getCategoryById(post.category_id);
            return (
              <article
                key={post.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 cursor-pointer group"
                onClick={() => navigate(`/blog/${post.id}`)}
              >
                <div className="relative h-56 overflow-hidden">
                  {post.image_url ? (
                    <img
                      src={post.image_url}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-pink-100 via-rose-50 to-pink-100 flex items-center justify-center">
                      <Tag className="w-16 h-16 text-pink-300" />
                    </div>
                  )}
                  {category && (
                    <div className="absolute top-4 left-4">
                      <span className="inline-block px-3 py-1 bg-white/90 backdrop-blur-sm text-pink-600 rounded-full text-xs font-medium shadow-md">
                        {category.name}
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
                    <Calendar className="w-3.5 h-3.5 text-pink-400" />
                    {formatDate(post.published_at)}
                  </div>

                  <h2 className="text-xl font-serif font-bold text-gray-900 mb-3 leading-tight group-hover:text-pink-600 transition-colors">
                    {post.title}
                  </h2>

                  <p className="text-gray-600 leading-relaxed text-sm font-light line-clamp-3 mb-4">
                    {post.excerpt}
                  </p>

                  <div className="flex items-center text-pink-500 text-sm font-medium group-hover:gap-2 transition-all">
                    <span>Read More</span>
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </main>

      <Footer />
    </div>
  );
}
