import Header from '../components/Header';
import Hero from '../components/Hero';
import BlogGrid from '../components/BlogGrid';
import Footer from '../components/Footer';
import FloatingShapes from '../components/FloatingShapes';
import BackToTop from '../components/BackToTop';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-50 animate-gradient-shift">
      <FloatingShapes />
      <BackToTop />
      <div className="relative z-10">
        <Header />
        <Hero />
        <BlogGrid />
        <Footer />
      </div>

      <style>{`
        @keyframes gradient-shift {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }

        .animate-gradient-shift {
          background-size: 200% 200%;
          animation: gradient-shift 15s ease infinite;
        }
      `}</style>
    </div>
  );
}
