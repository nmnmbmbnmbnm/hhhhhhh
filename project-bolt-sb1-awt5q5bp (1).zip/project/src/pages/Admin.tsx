import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Post } from '../lib/supabase';
import { Plus, Edit2, Trash2, ArrowLeft, ExternalLink, HelpCircle, BarChart3 } from 'lucide-react';
import PostForm from '../components/PostForm';
import QuizEditor from '../components/QuizEditor';
import PollEditor from '../components/PollEditor';

type EditingPost = Post | null;

type PostWithInteractive = Post & {
  hasQuiz: boolean;
  hasPoll: boolean;
};

export default function Admin() {
  const { user, loading: authLoading, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();
  const [posts, setPosts] = useState<PostWithInteractive[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editingPost, setEditingPost] = useState<EditingPost>(null);
  const [showForm, setShowForm] = useState(false);
  const [showQuizEditor, setShowQuizEditor] = useState(false);
  const [showPollEditor, setShowPollEditor] = useState(false);
  const [selectedPostForInteractive, setSelectedPostForInteractive] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    } else if (!authLoading && user && !isAdmin) {
      navigate('/');
    }
  }, [user, authLoading, isAdmin, navigate]);

  useEffect(() => {
    if (user) {
      fetchPosts();
    }
  }, [user]);

  const fetchPosts = async () => {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from('posts')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const postsWithInteractive = await Promise.all(
        (data || []).map(async (post) => {
          const [quizResult, pollResult] = await Promise.all([
            supabase.from('post_quizzes').select('id').eq('post_id', post.id).maybeSingle(),
            supabase.from('post_polls').select('id').eq('post_id', post.id).maybeSingle()
          ]);
          return {
            ...post,
            hasQuiz: !!quizResult.data,
            hasPoll: !!pollResult.data
          };
        })
      );

      setPosts(postsWithInteractive);
    } catch (err) {
      setError('Failed to load posts');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this post?')) return;

    try {
      const { error: deleteError } = await supabase
        .from('posts')
        .delete()
        .eq('id', postId)
        .eq('user_id', user?.id);

      if (deleteError) throw deleteError;
      setPosts(posts.filter((p) => p.id !== postId));
    } catch (err) {
      setError('Failed to delete post');
    }
  };

  const handleFormClose = () => {
    setShowForm(false);
    setEditingPost(null);
  };

  const handlePostSaved = () => {
    fetchPosts();
    handleFormClose();
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const openQuizEditor = (postId: string) => {
    setSelectedPostForInteractive(postId);
    setShowQuizEditor(true);
  };

  const openPollEditor = (postId: string) => {
    setSelectedPostForInteractive(postId);
    setShowPollEditor(true);
  };

  const closeInteractiveEditor = () => {
    setShowQuizEditor(false);
    setShowPollEditor(false);
    setSelectedPostForInteractive(null);
    fetchPosts();
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-600">Loading...</div>
      </div>
    );
  }

  if (!user || !isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-2xl font-bold text-slate-900">Blog Admin</h1>
            <div className="flex items-center gap-4">
              <span className="text-sm text-slate-600">{user.email}</span>
              <button
                onClick={handleSignOut}
                className="px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg transition"
              >
                Sign Out
              </button>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="inline-flex items-center gap-2 px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg transition group"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
              <span className="text-sm">Back to Home</span>
            </Link>
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 px-4 py-2 text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition group"
            >
              <span className="text-sm">View Blog</span>
              <ExternalLink className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-slate-900">Your Posts</h2>
          {!showForm && (
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition"
            >
              <Plus size={20} />
              New Post
            </button>
          )}
        </div>

        {showForm && (
          <div className="mb-8">
            <PostForm post={editingPost} onClose={handleFormClose} onSaved={handlePostSaved} />
          </div>
        )}

        {loading ? (
          <div className="text-center text-slate-600 py-12">Loading posts...</div>
        ) : posts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-slate-600 mb-4">No posts yet. Create your first one!</p>
            {!showForm && (
              <button
                onClick={() => setShowForm(true)}
                className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition"
              >
                <Plus size={20} />
                Create Post
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => (
              <div
                key={post.id}
                className="bg-white rounded-lg border border-slate-200 p-6 hover:border-slate-300 transition"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">{post.title}</h3>
                    <p className="text-slate-600 text-sm mb-3 line-clamp-2">{post.excerpt}</p>
                    <div className="flex items-center gap-3 text-xs mb-3">
                      <span>
                        {post.published ? (
                          <span className="inline-block px-2 py-1 bg-green-100 text-green-800 rounded">
                            Published
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-1 bg-yellow-100 text-yellow-800 rounded">
                            Draft
                          </span>
                        )}
                      </span>
                      <span className="text-slate-500">{new Date(post.created_at).toLocaleDateString()}</span>
                      {post.hasQuiz && (
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs">
                          <HelpCircle size={12} />
                          Kviz
                        </span>
                      )}
                      {post.hasPoll && (
                        <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                          <BarChart3 size={12} />
                          Szavazas
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openQuizEditor(post.id)}
                        className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                          post.hasQuiz
                            ? 'bg-amber-100 text-amber-700 hover:bg-amber-200'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                        title={post.hasQuiz ? 'Kviz szerkesztese' : 'Kviz hozzaadasa'}
                      >
                        <HelpCircle size={14} />
                        {post.hasQuiz ? 'Kviz' : 'Kviz +'}
                      </button>
                      <button
                        onClick={() => openPollEditor(post.id)}
                        className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                          post.hasPoll
                            ? 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                        title={post.hasPoll ? 'Szavazas szerkesztese' : 'Szavazas hozzaadasa'}
                      >
                        <BarChart3 size={14} />
                        {post.hasPoll ? 'Szavazas' : 'Szavazas +'}
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setEditingPost(post);
                        setShowForm(true);
                      }}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                      title="Edit post"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(post.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                      title="Delete post"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showQuizEditor && selectedPostForInteractive && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <QuizEditor postId={selectedPostForInteractive} onClose={closeInteractiveEditor} />
          </div>
        </div>
      )}

      {showPollEditor && selectedPostForInteractive && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-2xl">
            <PollEditor postId={selectedPostForInteractive} onClose={closeInteractiveEditor} />
          </div>
        </div>
      )}
    </div>
  );
}
