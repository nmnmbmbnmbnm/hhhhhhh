import { useEffect, useState } from 'react';

type Shape = {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
  type: 'circle' | 'square' | 'triangle';
};

export default function FloatingShapes() {
  const [shapes, setShapes] = useState<Shape[]>([]);

  useEffect(() => {
    const newShapes: Shape[] = [];
    for (let i = 0; i < 15; i++) {
      newShapes.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 60 + 20,
        duration: Math.random() * 20 + 15,
        delay: Math.random() * 5,
        type: ['circle', 'square', 'triangle'][Math.floor(Math.random() * 3)] as Shape['type'],
      });
    }
    setShapes(newShapes);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {shapes.map((shape) => (
        <div
          key={shape.id}
          className="absolute animate-float"
          style={{
            left: `${shape.x}%`,
            top: `${shape.y}%`,
            width: `${shape.size}px`,
            height: `${shape.size}px`,
            animationDuration: `${shape.duration}s`,
            animationDelay: `${shape.delay}s`,
          }}
        >
          {shape.type === 'circle' && (
            <div className="w-full h-full rounded-full bg-gradient-to-br from-pink-200/20 to-rose-200/20 blur-xl" />
          )}
          {shape.type === 'square' && (
            <div className="w-full h-full rotate-45 bg-gradient-to-br from-pink-200/15 to-rose-200/15 blur-lg" />
          )}
          {shape.type === 'triangle' && (
            <div className="w-0 h-0 border-l-[30px] border-l-transparent border-r-[30px] border-r-transparent border-b-[52px] border-b-pink-200/15 blur-lg" />
          )}
        </div>
      ))}

      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translate(0, 0) rotate(0deg);
            opacity: 0.5;
          }
          25% {
            transform: translate(20px, -30px) rotate(90deg);
            opacity: 0.8;
          }
          50% {
            transform: translate(-20px, -60px) rotate(180deg);
            opacity: 0.3;
          }
          75% {
            transform: translate(30px, -30px) rotate(270deg);
            opacity: 0.7;
          }
        }

        .animate-float {
          animation: float linear infinite;
        }
      `}</style>
    </div>
  );
}
