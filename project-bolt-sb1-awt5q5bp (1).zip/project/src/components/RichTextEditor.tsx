import { useRef, forwardRef, useImperativeHandle, useState, useEffect } from 'react';
import ReactQuill, { Quill } from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Moon, Sun, Eye, EyeOff } from 'lucide-react';
import { waitForPinterestAndBuild } from '../lib/pinterest';

const BlockEmbed = Quill.import('blots/block/embed');

class PinterestBlot extends BlockEmbed {
  static blotName = 'pinterest';
  static tagName = 'div';
  static className = 'pinterest-embed-container';

  static create(value: string) {
    const node = super.create() as HTMLElement;
    node.setAttribute('contenteditable', 'false');
    node.style.margin = '24px 0';
    node.style.textAlign = 'center';

    const link = document.createElement('a');
    link.setAttribute('data-pin-do', 'embedPin');
    link.setAttribute('data-pin-width', 'medium');
    link.setAttribute('href', value);

    node.appendChild(link);

    const buildWidget = () => {
      if (window.PinUtils) {
        try {
          window.PinUtils.build();
        } catch (error) {
          console.warn('Pinterest build error:', error);
        }
      } else {
        setTimeout(buildWidget, 200);
      }
    };

    setTimeout(buildWidget, 100);

    return node;
  }

  static value(node: HTMLElement) {
    const link = node.querySelector('a[data-pin-do]');
    return link?.getAttribute('href') || '';
  }
}

Quill.register(PinterestBlot);

type RichTextEditorProps = {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
};

export type RichTextEditorRef = {
  insertHTML: (html: string) => void;
  insertPinterest: (url: string) => void;
};

const RichTextEditor = forwardRef<RichTextEditorRef, RichTextEditorProps>(
  ({ value, onChange, placeholder }, ref) => {
    const quillRef = useRef<ReactQuill>(null);
    const [darkMode, setDarkMode] = useState(() => {
      const saved = localStorage.getItem('editor-dark-mode');
      return saved === 'true';
    });
    const [showPreview, setShowPreview] = useState(false);

    useEffect(() => {
      localStorage.setItem('editor-dark-mode', String(darkMode));
    }, [darkMode]);

    useEffect(() => {
      if (showPreview && value.includes('data-pin-do')) {
        const timer = setTimeout(() => {
          waitForPinterestAndBuild();
        }, 300);
        return () => clearTimeout(timer);
      }
    }, [showPreview, value]);

    useEffect(() => {
      if (!showPreview && value.includes('data-pin-do')) {
        const timer = setTimeout(() => {
          waitForPinterestAndBuild();
        }, 500);
        return () => clearTimeout(timer);
      }
    }, [value, showPreview]);

    useImperativeHandle(ref, () => ({
      insertHTML: (html: string) => {
        const editor = quillRef.current?.getEditor();
        if (!editor) return;

        const range = editor.getSelection();
        if (range) {
          editor.clipboard.dangerouslyPasteHTML(range.index, html);
        }
      },
      insertPinterest: (url: string) => {
        const editor = quillRef.current?.getEditor();
        if (!editor) return;

        const range = editor.getSelection() || { index: editor.getLength() };
        editor.insertEmbed(range.index, 'pinterest', url, 'user');
        editor.setSelection(range.index + 1, 0);
      }
    }));

    const modules = {
      toolbar: [
        [{ 'header': [1, 2, false] }],
        ['bold', 'italic', 'underline'],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
        ['link'],
        ['clean']
      ],
      clipboard: {
        matchVisual: false
      }
    };

    const formats = [
      'header',
      'bold', 'italic', 'underline',
      'list', 'bullet',
      'link',
      'image',
      'pinterest'
    ];

    return (
      <div className={`${darkMode ? 'dark' : ''}`}>
        <div className="flex items-center justify-end gap-2 mb-3">
          <button
            type="button"
            onClick={() => setShowPreview(!showPreview)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition ${
              showPreview
                ? 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            title={showPreview ? 'Hide preview' : 'Show preview'}
          >
            {showPreview ? <EyeOff size={16} /> : <Eye size={16} />}
            {showPreview ? 'Edit' : 'Preview'}
          </button>
          <button
            type="button"
            onClick={() => setDarkMode(!darkMode)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-sm font-medium transition"
            title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {darkMode ? <Sun size={16} /> : <Moon size={16} />}
            {darkMode ? 'Light' : 'Dark'}
          </button>
        </div>

        {showPreview ? (
          <div className={`min-h-[400px] border rounded-lg p-6 ${
            darkMode
              ? 'bg-slate-900 border-slate-700 text-slate-100'
              : 'bg-white border-slate-300 text-slate-900'
          }`}>
            <div className="prose prose-slate max-w-none dark:prose-invert">
              <div
                className="text-base leading-relaxed preview-content"
                dangerouslySetInnerHTML={{ __html: value }}
              />
            </div>
          </div>
        ) : (
          <div className={`quill-wrapper ${darkMode ? 'quill-dark' : ''}`}>
            <ReactQuill
              ref={quillRef}
              theme="snow"
              value={value}
              onChange={onChange}
              modules={modules}
              formats={formats}
              placeholder={placeholder}
              className={darkMode ? 'dark-editor' : ''}
            />
          </div>
        )}

        <style>{`
          .quill-wrapper {
            border: 1px solid rgb(203 213 225);
            border-radius: 0.5rem;
            overflow: hidden;
          }

          .quill-dark {
            border-color: rgb(51 65 85);
          }

          .quill-wrapper .ql-toolbar {
            background: rgb(248 250 252);
            border: none;
            border-bottom: 1px solid rgb(203 213 225);
            padding: 12px;
          }

          .quill-dark .ql-toolbar {
            background: rgb(30 41 59);
            border-bottom-color: rgb(51 65 85);
          }

          .quill-wrapper .ql-container {
            border: none;
            font-size: 16px;
            min-height: 400px;
            background: white;
          }

          .quill-dark .ql-container {
            background: rgb(15 23 42);
          }

          .quill-wrapper .ql-editor {
            min-height: 400px;
            padding: 20px;
            color: rgb(51 65 85);
          }

          .quill-dark .ql-editor {
            color: rgb(226 232 240);
          }

          .quill-wrapper .ql-editor.ql-blank::before {
            color: rgb(148 163 184);
            font-style: normal;
          }

          .quill-dark .ql-editor.ql-blank::before {
            color: rgb(100 116 139);
          }

          .quill-dark .ql-stroke {
            stroke: rgb(226 232 240) !important;
          }

          .quill-dark .ql-fill {
            fill: rgb(226 232 240) !important;
          }

          .quill-dark .ql-picker-label {
            color: rgb(226 232 240) !important;
          }

          .quill-wrapper .ql-toolbar button:hover,
          .quill-wrapper .ql-toolbar button.ql-active {
            background: rgb(219 234 254);
            color: rgb(59 130 246);
          }

          .quill-dark .ql-toolbar button:hover,
          .quill-dark .ql-toolbar button.ql-active {
            background: rgb(30 58 138);
          }

          .quill-wrapper .ql-editor strong {
            font-weight: 700;
          }

          .quill-wrapper .ql-editor em {
            font-style: italic;
          }

          .quill-wrapper .ql-editor u {
            text-decoration: underline;
          }

          .quill-wrapper .ql-editor h1 {
            font-size: 2em;
            font-weight: 700;
            margin: 0.67em 0;
          }

          .quill-wrapper .ql-editor h2 {
            font-size: 1.5em;
            font-weight: 700;
            margin: 0.75em 0;
          }

          .quill-wrapper .ql-editor ul,
          .quill-wrapper .ql-editor ol {
            padding-left: 1.5em;
          }

          .quill-wrapper .ql-editor a {
            color: rgb(59 130 246);
            text-decoration: underline;
          }

          .quill-dark .ql-editor a {
            color: rgb(96 165 250);
          }

          .quill-wrapper .ql-editor img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin: 16px 0;
          }

          .quill-wrapper .ql-editor .pinterest-embed-container {
            margin: 24px 0 !important;
            text-align: center !important;
            display: block !important;
          }

          .quill-wrapper .ql-editor .pinterest-embed-container span[data-pin-log="embed_pin"] {
            display: inline-block !important;
          }

          .quill-wrapper .ql-editor .pinterest-embed-container iframe {
            max-width: 100% !important;
            margin: 0 auto !important;
          }

          .preview-content .pinterest-embed-container {
            margin: 24px 0 !important;
            text-align: center !important;
            display: block !important;
          }

          .preview-content .pinterest-embed-container span[data-pin-log="embed_pin"] {
            display: inline-block !important;
          }

          .preview-content .pinterest-embed-container iframe {
            max-width: 100% !important;
            margin: 0 auto !important;
          }
        `}</style>
      </div>
    );
  }
);

RichTextEditor.displayName = 'RichTextEditor';

export default RichTextEditor;
