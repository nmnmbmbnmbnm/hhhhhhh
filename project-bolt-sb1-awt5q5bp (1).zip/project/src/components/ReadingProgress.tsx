import { useEffect, useState } from 'react';

export default function ReadingProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const updateProgress = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercent = (scrollTop / docHeight) * 100;
      setProgress(scrollPercent);
    };

    window.addEventListener('scroll', updateProgress);
    updateProgress();

    return () => window.removeEventListener('scroll', updateProgress);
  }, []);

  return (
    <div className="fixed top-0 left-0 w-full h-1 bg-pink-100/30 z-50">
      <div
        className="h-full bg-gradient-to-r from-pink-400 via-rose-400 to-pink-500 transition-all duration-150 ease-out shadow-lg shadow-pink-500/50"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}
