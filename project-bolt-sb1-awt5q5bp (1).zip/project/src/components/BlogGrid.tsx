import { useState, useEffect } from 'react';
import { supabase, Post, Category } from '../lib/supabase';
import CategoryFilter from './CategoryFilter';
import BlogCard from './BlogCard';
import LoadingSkeleton from './LoadingSkeleton';

export default function BlogGrid() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCategories();
    fetchPosts();
  }, [selectedCategory]);

  const fetchCategories = async () => {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('name');

    if (!error && data) {
      setCategories(data);
    }
  };

  const fetchPosts = async () => {
    setLoading(true);
    let query = supabase
      .from('posts')
      .select('*')
      .eq('published', true)
      .order('published_at', { ascending: false });

    if (selectedCategory) {
      query = query.eq('category_id', selectedCategory);
    }

    const { data, error } = await query;

    if (!error && data) {
      setPosts(data);
    }
    setLoading(false);
  };

  const getCategoryById = (categoryId: string | null) => {
    return categories.find((cat) => cat.id === categoryId) || null;
  };

  return (
    <section id="blog" className="relative py-12 sm:py-16 md:py-24 bg-gradient-to-b from-white via-pink-50/30 to-white overflow-hidden">
      <div className="absolute top-0 right-0 w-32 sm:w-48 md:w-64 h-32 sm:h-48 md:h-64 bg-gradient-to-bl from-pink-100/30 to-transparent rounded-bl-[75px] sm:rounded-bl-[100px] md:rounded-bl-[150px]"></div>
      <div className="absolute bottom-0 left-0 w-32 sm:w-48 md:w-64 h-32 sm:h-48 md:h-64 bg-gradient-to-tr from-rose-100/30 to-transparent rounded-tr-[75px] sm:rounded-tr-[100px] md:rounded-tr-[150px]"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-8 sm:mb-12 md:mb-16">
          <div className="inline-block relative mb-4">
            <div className="absolute -top-1 sm:-top-2 -left-1 sm:-left-2 w-6 sm:w-10 md:w-12 h-6 sm:h-10 md:h-12 border-l border-t border-pink-300/50"></div>
            <div className="absolute -bottom-1 sm:-bottom-2 -right-1 sm:-right-2 w-6 sm:w-10 md:w-12 h-6 sm:h-10 md:h-12 border-r border-b border-rose-300/50"></div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-gray-900 px-4 sm:px-6 py-2">
              Latest <span className="bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 bg-clip-text text-transparent">Stories</span>
            </h2>
          </div>
          <div className="w-24 sm:w-32 h-0.5 bg-gradient-to-r from-transparent via-pink-300 to-transparent mx-auto mb-4 sm:mb-6"></div>
          <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto font-light tracking-wide px-4">
            Explore thoughts across different topics and find what speaks to your soul
          </p>
        </div>

        <CategoryFilter
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />

        {loading ? (
          <LoadingSkeleton />
        ) : posts.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-xl text-gray-500 font-light">No posts yet. Check back soon!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {posts.map((post, index) => (
              <BlogCard
                key={post.id}
                post={post}
                category={getCategoryById(post.category_id)}
                index={index}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
