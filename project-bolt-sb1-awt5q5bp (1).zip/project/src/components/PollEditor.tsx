import { useState, useEffect } from 'react';
import { Plus, Trash2, X, GripVertical } from 'lucide-react';
import { supabase } from '../lib/supabase';

type PollOption = {
  id?: string;
  option_text: string;
  order_index: number;
};

type Poll = {
  id?: string;
  question: string;
  allow_multiple: boolean;
  options: PollOption[];
};

type PollEditorProps = {
  postId: string;
  onClose: () => void;
};

export default function PollEditor({ postId, onClose }: PollEditorProps) {
  const [poll, setPoll] = useState<Poll>({
    question: '',
    allow_multiple: false,
    options: [
      { option_text: '', order_index: 0 },
      { option_text: '', order_index: 1 }
    ]
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchExistingPoll();
  }, [postId]);

  const fetchExistingPoll = async () => {
    setLoading(true);
    const { data: pollData } = await supabase
      .from('post_polls')
      .select('*')
      .eq('post_id', postId)
      .maybeSingle();

    if (pollData) {
      const { data: optionsData } = await supabase
        .from('poll_options')
        .select('*')
        .eq('poll_id', pollData.id)
        .order('order_index');

      setPoll({
        ...pollData,
        options: optionsData || []
      });
    }

    setLoading(false);
  };

  const addOption = () => {
    setPoll(prev => ({
      ...prev,
      options: [...prev.options, { option_text: '', order_index: prev.options.length }]
    }));
  };

  const removeOption = (index: number) => {
    setPoll(prev => ({
      ...prev,
      options: prev.options.filter((_, i) => i !== index).map((o, i) => ({ ...o, order_index: i }))
    }));
  };

  const updateOption = (index: number, text: string) => {
    setPoll(prev => ({
      ...prev,
      options: prev.options.map((o, i) => i === index ? { ...o, option_text: text } : o)
    }));
  };

  const handleSave = async () => {
    if (!poll.question.trim()) {
      setError('Add meg a szavazas kerdeset');
      return;
    }

    if (poll.options.length < 2) {
      setError('Legalabb 2 valaszlehetoseg szukseges');
      return;
    }

    for (const o of poll.options) {
      if (!o.option_text.trim()) {
        setError('Minden valaszlehetoseg szovege kotelezo');
        return;
      }
    }

    setSaving(true);
    setError('');

    try {
      let pollId = poll.id;

      if (pollId) {
        await supabase
          .from('post_polls')
          .update({ question: poll.question, allow_multiple: poll.allow_multiple })
          .eq('id', pollId);

        await supabase
          .from('poll_options')
          .delete()
          .eq('poll_id', pollId);
      } else {
        const { data: newPoll, error: pollError } = await supabase
          .from('post_polls')
          .insert({ post_id: postId, question: poll.question, allow_multiple: poll.allow_multiple })
          .select()
          .single();

        if (pollError) throw pollError;
        pollId = newPoll.id;
      }

      const optionsToInsert = poll.options.map(o => ({
        poll_id: pollId,
        option_text: o.option_text,
        order_index: o.order_index
      }));

      const { error: optionsError } = await supabase
        .from('poll_options')
        .insert(optionsToInsert);

      if (optionsError) throw optionsError;

      onClose();
    } catch {
      setError('Hiba tortent a mentes soran');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!poll.id) {
      onClose();
      return;
    }

    if (!confirm('Biztosan torlod a szavazast? Az osszes szavazat is torlodni fog.')) return;

    setSaving(true);
    await supabase.from('post_polls').delete().eq('id', poll.id);
    setSaving(false);
    onClose();
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg border border-slate-200 p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-slate-200 rounded w-1/3"></div>
          <div className="h-10 bg-slate-100 rounded"></div>
          <div className="h-32 bg-slate-100 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-slate-900">Szavazas szerkeszto</h3>
        <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-lg transition">
          <X size={24} className="text-slate-600" />
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Szavazas kerdese *</label>
          <input
            type="text"
            value={poll.question}
            onChange={(e) => setPoll(prev => ({ ...prev, question: e.target.value }))}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            placeholder="Pl.: Mi a kedvenc evszakod?"
          />
        </div>

        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            id="allowMultiple"
            checked={poll.allow_multiple}
            onChange={(e) => setPoll(prev => ({ ...prev, allow_multiple: e.target.checked }))}
            className="w-4 h-4 border border-slate-300 rounded focus:ring-2 focus:ring-blue-500"
          />
          <label htmlFor="allowMultiple" className="text-sm font-medium text-slate-700">
            Tobb valasz is kivalaszthato
          </label>
        </div>

        <div className="border-t border-slate-200 pt-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-slate-800">Valaszlehetosegek</h4>
            <button
              type="button"
              onClick={addOption}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition"
            >
              <Plus size={16} />
              Uj opcio
            </button>
          </div>

          <div className="space-y-3">
            {poll.options.map((option, index) => (
              <div key={index} className="flex items-center gap-2">
                <GripVertical size={18} className="text-slate-400 cursor-move" />
                <input
                  type="text"
                  value={option.option_text}
                  onChange={(e) => updateOption(index, e.target.value)}
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder={`${index + 1}. opcio`}
                />
                {poll.options.length > 2 && (
                  <button
                    type="button"
                    onClick={() => removeOption(index)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition"
                  >
                    <Trash2 size={18} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3 pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="flex-1 bg-blue-500 text-white py-2 rounded-lg font-medium hover:bg-blue-600 transition disabled:opacity-50"
          >
            {saving ? 'Mentes...' : 'Szavazas mentese'}
          </button>
          {poll.id && (
            <button
              type="button"
              onClick={handleDelete}
              disabled={saving}
              className="px-4 py-2 bg-red-100 text-red-600 rounded-lg font-medium hover:bg-red-200 transition disabled:opacity-50"
            >
              Torles
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg font-medium hover:bg-slate-300 transition"
          >
            Megse
          </button>
        </div>
      </div>
    </div>
  );
}
