import { useState, useEffect, useRef } from 'react';
import { supabase, Post, Category } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { X, Image, Video, Upload, HelpCircle, BarChart3, Save, CheckCircle, Pin } from 'lucide-react';
import RichTextEditor, { RichTextEditorRef } from './RichTextEditor';
import QuizEditor from './QuizEditor';
import PollEditor from './PollEditor';
import { waitForPinterestAndBuild, resolvePinItUrl } from '../lib/pinterest';

type PostFormProps = {
  post: Post | null;
  onClose: () => void;
  onSaved: () => void;
};

type SaveStatus = 'idle' | 'saving' | 'saved';

export default function PostForm({ post, onClose, onSaved }: PostFormProps) {
  const { user } = useAuth();
  const editorRef = useRef<RichTextEditorRef>(null);
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [title, setTitle] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [published, setPublished] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadingContent, setUploadingContent] = useState(false);
  const contentFileInputRef = useRef<HTMLInputElement>(null);
  const [showQuizEditor, setShowQuizEditor] = useState(false);
  const [showPollEditor, setShowPollEditor] = useState(false);
  const [hasQuiz, setHasQuiz] = useState(false);
  const [hasPoll, setHasPoll] = useState(false);
  const [draftId, setDraftId] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>('idle');

  useEffect(() => {
    fetchCategories();
    if (post) {
      setTitle(post.title);
      setExcerpt(post.excerpt);
      setContent(post.content);
      setCategoryId(post.category_id || '');
      setImageUrl(post.image_url);
      setPublished(post.published);
      checkInteractiveElements(post.id);
      loadDraft(post.id);
    } else {
      setTitle('');
      setExcerpt('');
      setContent('');
      setCategoryId('');
      setImageUrl('');
      setPublished(false);
      setHasQuiz(false);
      setHasPoll(false);
      loadDraft(null);
    }
    setSelectedFile(null);
    setError('');

    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, [post]);

  useEffect(() => {
    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
    }

    autoSaveTimerRef.current = setTimeout(() => {
      saveDraft();
    }, 10000);

    return () => {
      if (autoSaveTimerRef.current) {
        clearTimeout(autoSaveTimerRef.current);
      }
    };
  }, [title, content, excerpt, categoryId, imageUrl, published]);

  const loadDraft = async (postId: string | null) => {
    if (!user) return;

    try {
      let query = supabase
        .from('post_drafts')
        .select('*')
        .eq('user_id', user.id);

      if (postId) {
        query = query.eq('post_id', postId);
      } else {
        query = query.is('post_id', null);
      }

      const { data, error } = await query.maybeSingle();

      if (error) throw error;

      if (data) {
        setDraftId(data.id);
        if (!post) {
          setTitle(data.title || '');
          setContent(data.content || '');
          setExcerpt(data.excerpt || '');
          setCategoryId(data.category_id || '');
          setImageUrl(data.image_url || '');
          setPublished(data.published);
        }
      }
    } catch (err) {
      console.error('Failed to load draft:', err);
    }
  };

  const saveDraft = async () => {
    if (!user || (!title && !content)) return;

    setSaveStatus('saving');

    try {
      const draftData = {
        user_id: user.id,
        post_id: post?.id || null,
        title,
        content,
        excerpt,
        category_id: categoryId || null,
        image_url: imageUrl,
        published,
        updated_at: new Date().toISOString(),
      };

      if (draftId) {
        const { error } = await supabase
          .from('post_drafts')
          .update(draftData)
          .eq('id', draftId);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('post_drafts')
          .insert([draftData])
          .select()
          .single();

        if (error) throw error;
        if (data) setDraftId(data.id);
      }

      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 2000);
    } catch (err) {
      console.error('Failed to save draft:', err);
      setSaveStatus('idle');
    }
  };

  const deleteDraft = async () => {
    if (!draftId) return;

    try {
      await supabase.from('post_drafts').delete().eq('id', draftId);
      setDraftId(null);
    } catch (err) {
      console.error('Failed to delete draft:', err);
    }
  };

  const checkInteractiveElements = async (postId: string) => {
    const [quizResult, pollResult] = await Promise.all([
      supabase.from('post_quizzes').select('id').eq('post_id', postId).maybeSingle(),
      supabase.from('post_polls').select('id').eq('post_id', postId).maybeSingle()
    ]);
    setHasQuiz(!!quizResult.data);
    setHasPoll(!!pollResult.data);
  };

  const fetchCategories = async () => {
    try {
      const { data, error: fetchError } = await supabase.from('categories').select('*');
      if (fetchError) throw fetchError;
      setCategories(data || []);
    } catch (err) {
      setError('Failed to load categories');
    }
  };

  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title || !content) {
      setError('Title and content are required');
      return;
    }

    setLoading(true);

    try {
      const slug = generateSlug(title);
      const postData = {
        title,
        slug,
        excerpt,
        content,
        category_id: categoryId || null,
        image_url: imageUrl,
        published,
        user_id: user?.id,
        published_at: published ? new Date().toISOString() : null,
      };

      if (post) {
        const { error: updateError } = await supabase
          .from('posts')
          .update(postData)
          .eq('id', post.id)
          .eq('user_id', user?.id);

        if (updateError) throw updateError;
      } else {
        const { error: insertError } = await supabase.from('posts').insert([postData]);
        if (insertError) throw insertError;
      }

      await deleteDraft();
      onSaved();
    } catch (err) {
      setError('Failed to save post');
    } finally {
      setLoading(false);
    }
  };

  const insertImageTag = () => {
    const imageUrl = prompt('Enter image URL (e.g., https://example.com/image.jpg):');
    if (!imageUrl) return;

    const altText = prompt('Enter alt text for the image (optional):') || 'Image';
    const imageTag = `<img src="${imageUrl}" alt="${altText}" style="max-width: 100%; height: auto; border-radius: 8px; margin: 16px 0;" />`;

    editorRef.current?.insertHTML(imageTag);
  };

  const insertVideoEmbed = () => {
    const videoUrl = prompt('Enter YouTube or Vimeo video URL:');
    if (!videoUrl) return;

    let embedCode = '';

    if (videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be')) {
      const videoId = videoUrl.includes('youtu.be')
        ? videoUrl.split('youtu.be/')[1]?.split('?')[0]
        : new URL(videoUrl).searchParams.get('v');

      if (videoId) {
        embedCode = `<div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; margin: 16px 0;"><iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border-radius: 8px;" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>`;
      }
    } else if (videoUrl.includes('vimeo.com')) {
      const videoId = videoUrl.split('vimeo.com/')[1]?.split('?')[0];
      if (videoId) {
        embedCode = `<div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; margin: 16px 0;"><iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border-radius: 8px;" src="https://player.vimeo.com/video/${videoId}" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe></div>`;
      }
    }

    if (!embedCode) {
      alert('Invalid YouTube or Vimeo URL. Please try again.');
      return;
    }

    editorRef.current?.insertHTML(embedCode);
  };

  const insertPinterestPin = async () => {
    const pinUrl = prompt('Enter Pinterest pin URL (e.g., https://pin.it/... or https://pinterest.com/pin/...):');
    if (!pinUrl) return;

    if (!pinUrl.includes('pinterest') && !pinUrl.includes('pin.it')) {
      alert('Please enter a valid Pinterest URL');
      return;
    }

    const finalUrl = await resolvePinItUrl(pinUrl.trim());

    editorRef.current?.insertPinterest(finalUrl);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size must be less than 5MB');
        return;
      }

      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        setError('Only JPG, PNG, GIF, and WebP images are supported');
        return;
      }

      setSelectedFile(file);
      setError('');
    }
  };

  const uploadImage = async () => {
    if (!selectedFile || !user) return;

    setUploading(true);
    setError('');

    try {
      const fileExt = selectedFile.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('blog-images')
        .upload(fileName, selectedFile, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('blog-images')
        .getPublicUrl(fileName);

      setImageUrl(publicUrl);
      setSelectedFile(null);
    } catch (err) {
      setError('Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleContentImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    if (file.size > 5 * 1024 * 1024) {
      setError('Image size must be less than 5MB');
      return;
    }

    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError('Only JPG, PNG, GIF, and WebP images are supported');
      return;
    }

    setUploadingContent(true);
    setError('');

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('blog-images')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('blog-images')
        .getPublicUrl(fileName);

      const altText = prompt('Enter alt text for the image (optional):') || 'Image';
      const imageTag = `<img src="${publicUrl}" alt="${altText}" style="max-width: 100%; height: auto; border-radius: 8px; margin: 16px 0;" />`;

      editorRef.current?.insertHTML(imageTag);
    } catch (err) {
      setError('Failed to upload image. Please try again.');
    } finally {
      setUploadingContent(false);
      if (contentFileInputRef.current) {
        contentFileInputRef.current.value = '';
      }
    }
  };

  const triggerContentImageUpload = () => {
    contentFileInputRef.current?.click();
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <h3 className="text-2xl font-bold text-slate-900">{post ? 'Edit Post' : 'Create New Post'}</h3>
          {saveStatus === 'saving' && (
            <span className="flex items-center gap-1.5 text-sm text-slate-500">
              <Save size={16} className="animate-pulse" />
              Saving...
            </span>
          )}
          {saveStatus === 'saved' && (
            <span className="flex items-center gap-1.5 text-sm text-green-600">
              <CheckCircle size={16} />
              All changes saved
            </span>
          )}
        </div>
        <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-lg transition">
          <X size={24} className="text-slate-600" />
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-slate-700 mb-2">
            Title *
          </label>
          <input
            id="title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
            placeholder="Post title"
          />
        </div>

        <div>
          <label htmlFor="category" className="block text-sm font-medium text-slate-700 mb-2">
            Category
          </label>
          <select
            id="category"
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
          >
            <option value="">Select a category (optional)</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="excerpt" className="block text-sm font-medium text-slate-700 mb-2">
            Excerpt
          </label>
          <textarea
            id="excerpt"
            value={excerpt}
            onChange={(e) => setExcerpt(e.target.value)}
            rows={2}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition resize-none"
            placeholder="Short summary of the post"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium text-slate-700">
              Content *
            </label>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={triggerContentImageUpload}
                disabled={uploadingContent}
                className="inline-flex items-center gap-1 px-3 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition disabled:opacity-50 disabled:cursor-not-allowed"
                title="Upload image from device"
              >
                <Upload size={14} />
                {uploadingContent ? 'Uploading...' : 'Upload Image'}
              </button>
              <button
                type="button"
                onClick={insertImageTag}
                className="inline-flex items-center gap-1 px-3 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition"
                title="Insert image from URL"
              >
                <Image size={14} />
                Image URL
              </button>
              <button
                type="button"
                onClick={insertVideoEmbed}
                className="inline-flex items-center gap-1 px-3 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition"
                title="Insert video"
              >
                <Video size={14} />
                Add Video
              </button>
              <button
                type="button"
                onClick={insertPinterestPin}
                className="inline-flex items-center gap-1 px-3 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition"
                title="Insert Pinterest pin"
              >
                <Pin size={14} />
                Pinterest
              </button>
            </div>
          </div>
          <input
            ref={contentFileInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
            onChange={handleContentImageSelect}
            className="hidden"
          />
          <RichTextEditor
            ref={editorRef}
            value={content}
            onChange={setContent}
            placeholder="Write your post content here... Use the toolbar to format text with headings, bold, italic, lists, and more."
          />
          <div className="mt-2 text-xs text-slate-500 bg-slate-50 rounded-lg p-3 border border-slate-200">
            <p className="font-semibold mb-1">Editor Features:</p>
            <ul className="space-y-1 ml-4 list-disc">
              <li><strong>Text Formatting:</strong> Use toolbar buttons for bold, italic, underline, and headings</li>
              <li><strong>Upload Image:</strong> Upload from your device and insert into content</li>
              <li><strong>Image URL:</strong> Insert image from an existing URL</li>
              <li><strong>Add Video:</strong> Embed YouTube or Vimeo videos</li>
              <li><strong>Pinterest:</strong> Paste any Pinterest pin URL to embed it</li>
              <li><strong>Lists & Alignment:</strong> Create bullet/numbered lists and align text</li>
              <li>Supports: JPG, PNG, GIF, WebP (max 5MB per image)</li>
            </ul>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Featured Image
          </label>

          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1">
                <label
                  htmlFor="imageFile"
                  className="flex items-center justify-center gap-2 px-4 py-2 border-2 border-dashed border-slate-300 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition cursor-pointer"
                >
                  <Upload size={18} className="text-slate-600" />
                  <span className="text-sm text-slate-600">
                    {selectedFile ? selectedFile.name : 'Choose image from device'}
                  </span>
                </label>
                <input
                  id="imageFile"
                  type="file"
                  accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </div>

              {selectedFile && (
                <button
                  type="button"
                  onClick={uploadImage}
                  disabled={uploading}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
                >
                  {uploading ? 'Uploading...' : 'Upload'}
                </button>
              )}
            </div>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="px-2 bg-white text-slate-500">OR</span>
              </div>
            </div>

            <input
              id="imageUrl"
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
              placeholder="Paste image URL (https://example.com/image.jpg)"
            />
          </div>

          {imageUrl && (
            <div className="mt-3 rounded-lg overflow-hidden border border-slate-200">
              <img
                src={imageUrl}
                alt="Preview"
                className="w-full h-48 object-cover"
                onError={() => setError('Failed to load image from URL')}
              />
            </div>
          )}

          <p className="mt-2 text-xs text-slate-500">
            Upload from your device (max 5MB) or paste a direct link to an image hosted online
          </p>
        </div>

        {post && (
          <div className="border-t border-slate-200 pt-6">
            <label className="block text-sm font-medium text-slate-700 mb-3">
              Interaktiv elemek
            </label>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setShowQuizEditor(true)}
                className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition ${
                  hasQuiz
                    ? 'bg-amber-100 text-amber-700 border border-amber-300 hover:bg-amber-200'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <HelpCircle size={18} />
                {hasQuiz ? 'Kviz szerkesztese' : 'Kviz hozzaadasa'}
              </button>
              <button
                type="button"
                onClick={() => setShowPollEditor(true)}
                className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition ${
                  hasPoll
                    ? 'bg-blue-100 text-blue-700 border border-blue-300 hover:bg-blue-200'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <BarChart3 size={18} />
                {hasPoll ? 'Szavazas szerkesztese' : 'Szavazas hozzaadasa'}
              </button>
            </div>
            <p className="mt-2 text-xs text-slate-500">
              Adj hozza interaktiv elemeket a bejegyzeshez, hogy az olvasok reszt vehessenek
            </p>
          </div>
        )}

        <div className="flex items-center gap-3 pt-4 border-t border-slate-200">
          <input
            id="published"
            type="checkbox"
            checked={published}
            onChange={(e) => setPublished(e.target.checked)}
            className="w-4 h-4 border border-slate-300 rounded focus:ring-2 focus:ring-blue-500"
          />
          <label htmlFor="published" className="text-sm font-medium text-slate-700">
            Publish this post
          </label>
        </div>

        <div className="flex items-center gap-3 pt-4">
          <button
            type="submit"
            disabled={loading}
            className="flex-1 bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Saving...' : post ? 'Update Post' : 'Create Post'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 bg-slate-200 text-slate-900 py-2 rounded-lg font-medium hover:bg-slate-300 transition"
          >
            Cancel
          </button>
        </div>
      </form>

      {showQuizEditor && post && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <QuizEditor
              postId={post.id}
              onClose={() => {
                setShowQuizEditor(false);
                checkInteractiveElements(post.id);
              }}
            />
          </div>
        </div>
      )}

      {showPollEditor && post && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-2xl">
            <PollEditor
              postId={post.id}
              onClose={() => {
                setShowPollEditor(false);
                checkInteractiveElements(post.id);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
