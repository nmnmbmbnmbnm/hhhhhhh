import { Heart, Flower2, PenTool, LogIn, UserPlus } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export default function Footer() {
  const { user, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <footer className="relative bg-gradient-to-br from-pink-100 via-rose-100 to-pink-50 py-10 sm:py-12 md:py-16 overflow-hidden">
      <div className="absolute top-0 left-0 w-16 sm:w-24 md:w-32 h-16 sm:h-24 md:h-32 border-l-2 border-t-2 border-pink-200/40 rounded-tl-2xl sm:rounded-tl-3xl hidden sm:block"></div>
      <div className="absolute bottom-0 right-0 w-16 sm:w-24 md:w-32 h-16 sm:h-24 md:h-32 border-r-2 border-b-2 border-rose-200/40 rounded-br-2xl sm:rounded-br-3xl hidden sm:block"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          <div className="inline-block relative mb-4 sm:mb-6">
            <div className="flex items-end">
              <svg className="w-4 h-8 sm:w-5 sm:h-10 flex-shrink-0 -mr-0.5" viewBox="0 0 32 64" fill="none">
                <ellipse cx="16" cy="5" rx="6" ry="3.5" fill="url(#footerPastelCapTop)" />
                <rect x="10" y="4" width="12" height="9" rx="1" fill="url(#footerPastelCapGradient)" />
                <path d="M11 13 Q16 15 21 13 L21 16 Q16 18 11 16 Z" fill="#f9a8d4" />
                <rect x="11" y="16" width="10" height="30" rx="2" fill="url(#footerPastelBodyGradient)" />
                <ellipse cx="16" cy="18" rx="4" ry="1" fill="rgba(255,255,255,0.4)" />
                <path d="M13 22 L19 22 L19 24 L13 24 Z" fill="#f472b6" opacity="0.5" />
                <path d="M13 46 L16 60 L19 46" fill="url(#footerPastelNibGradient)" />
                <defs>
                  <linearGradient id="footerPastelCapTop" x1="10" y1="0" x2="22" y2="0">
                    <stop offset="0%" stopColor="#f9a8d4" />
                    <stop offset="50%" stopColor="#fbcfe8" />
                    <stop offset="100%" stopColor="#f9a8d4" />
                  </linearGradient>
                  <linearGradient id="footerPastelCapGradient" x1="10" y1="0" x2="22" y2="0">
                    <stop offset="0%" stopColor="#f472b6" />
                    <stop offset="30%" stopColor="#f9a8d4" />
                    <stop offset="70%" stopColor="#fbcfe8" />
                    <stop offset="100%" stopColor="#f472b6" />
                  </linearGradient>
                  <linearGradient id="footerPastelBodyGradient" x1="11" y1="0" x2="21" y2="0">
                    <stop offset="0%" stopColor="#f472b6" />
                    <stop offset="25%" stopColor="#f9a8d4" />
                    <stop offset="50%" stopColor="#fbcfe8" />
                    <stop offset="75%" stopColor="#f9a8d4" />
                    <stop offset="100%" stopColor="#f472b6" />
                  </linearGradient>
                  <linearGradient id="footerPastelNibGradient" x1="13" y1="46" x2="19" y2="60">
                    <stop offset="0%" stopColor="#fbcfe8" />
                    <stop offset="100%" stopColor="#f9a8d4" />
                  </linearGradient>
                </defs>
              </svg>
              <h3 className="text-xl sm:text-2xl font-serif font-bold tracking-tight">
                <span className="text-pink-400">Woman</span>
                <span className="text-gray-700">thoughts</span>
              </h3>
            </div>
            <svg className="absolute -bottom-1 left-0 w-full h-3 sm:h-4" viewBox="0 0 200 16" preserveAspectRatio="none">
              <path d="M 8 2 Q 50 10, 100 5 T 200 8" fill="none" stroke="#f9a8d4" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>

          <div className="flex items-center justify-center space-x-2 mb-3 sm:mb-4 text-sm sm:text-base">
            <span className="text-gray-600 font-light">Made with</span>
            <Heart className="w-4 h-4 sm:w-5 sm:h-5 text-pink-500 fill-pink-500 animate-pulse" />
            <span className="text-gray-600 font-light">and</span>
            <svg className="w-3 h-6 sm:w-4 sm:h-7" viewBox="0 0 32 64" fill="none">
              <ellipse cx="16" cy="5" rx="6" ry="3.5" fill="url(#madeWithPastelCapTop)" />
              <rect x="10" y="4" width="12" height="9" rx="1" fill="url(#madeWithPastelCapGradient)" />
              <rect x="11" y="13" width="10" height="30" rx="2" fill="url(#madeWithPastelBodyGradient)" />
              <path d="M13 43 L16 56 L19 43" fill="#f9a8d4" />
              <defs>
                <linearGradient id="madeWithPastelCapTop" x1="10" y1="0" x2="22" y2="0">
                  <stop offset="0%" stopColor="#f9a8d4" />
                  <stop offset="50%" stopColor="#fbcfe8" />
                  <stop offset="100%" stopColor="#f9a8d4" />
                </linearGradient>
                <linearGradient id="madeWithPastelCapGradient" x1="10" y1="0" x2="22" y2="0">
                  <stop offset="0%" stopColor="#f472b6" />
                  <stop offset="50%" stopColor="#fbcfe8" />
                  <stop offset="100%" stopColor="#f472b6" />
                </linearGradient>
                <linearGradient id="madeWithPastelBodyGradient" x1="11" y1="0" x2="21" y2="0">
                  <stop offset="0%" stopColor="#f472b6" />
                  <stop offset="50%" stopColor="#fbcfe8" />
                  <stop offset="100%" stopColor="#f472b6" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          <p className="text-gray-500 text-xs sm:text-sm font-light tracking-wide">
            © {new Date().getFullYear()} thewomanthoughts.com. All rights reserved.
          </p>

          <div className="mt-4 space-y-2">
            <a
              href="mailto:womanthoughts.contact@gmail.com"
              className="text-gray-600 hover:text-pink-500 text-xs sm:text-sm font-light transition-colors block"
            >
              womanthoughts.contact@gmail.com
            </a>
            <div className="flex items-center justify-center gap-3">
              <Link to="/privacy" className="text-gray-600 hover:text-pink-500 text-xs sm:text-sm font-light underline transition-colors">
                Privacy Policy
              </Link>
              <span className="text-gray-400">|</span>
              <Link to="/affiliate-disclaimer" className="text-gray-600 hover:text-pink-500 text-xs sm:text-sm font-light underline transition-colors">
                Affiliate Disclaimer
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-4 right-4 flex items-center gap-3">
          {user ? (
            <>
              {isAdmin && (
                <Link
                  to="/admin"
                  className="p-3 bg-white/80 hover:bg-white rounded-full shadow-md hover:shadow-lg transition-all duration-300 group"
                  title="Admin"
                >
                  <PenTool className="w-5 h-5 text-pink-500 group-hover:text-rose-500 transition-colors" />
                </Link>
              )}
              <button
                onClick={handleSignOut}
                className="p-3 bg-white/80 hover:bg-white rounded-full shadow-md hover:shadow-lg transition-all duration-300 group"
                title="Logout"
              >
                <Flower2 className="w-5 h-5 text-pink-500 group-hover:text-rose-500 transition-colors" />
              </button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                className="p-3 bg-white/80 hover:bg-white rounded-full shadow-md hover:shadow-lg transition-all duration-300 group"
                title="Login"
              >
                <LogIn className="w-5 h-5 text-pink-500 group-hover:text-rose-500 transition-colors" />
              </Link>
              <Link
                to="/signup"
                className="p-3 bg-white/80 hover:bg-white rounded-full shadow-md hover:shadow-lg transition-all duration-300 group"
                title="Sign Up"
              >
                <UserPlus className="w-5 h-5 text-pink-500 group-hover:text-rose-500 transition-colors" />
              </Link>
            </>
          )}
        </div>
      </div>
    </footer>
  );
}
