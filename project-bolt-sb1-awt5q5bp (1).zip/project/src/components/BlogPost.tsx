import { useState, useEffect } from 'react';
import { ArrowLeft, Calendar, Tag } from 'lucide-react';
import { Post, Category, supabase } from '../lib/supabase';
import QuizBlock from './QuizBlock';
import PollBlock from './PollBlock';
import { waitForPinterestAndBuild } from '../lib/pinterest';
import ReadingProgress from './ReadingProgress';
import BackToTop from './BackToTop';
import Breadcrumb from './Breadcrumb';
import ImageLightbox from './ImageLightbox';

type BlogPostProps = {
  post: Post;
  onBack: () => void;
};

export default function BlogPost({ post, onBack }: BlogPostProps) {
  const [category, setCategory] = useState<Category | null>(null);
  const [quizId, setQuizId] = useState<string | null>(null);
  const [pollId, setPollId] = useState<string | null>(null);
  const [lightboxImage, setLightboxImage] = useState<{ src: string; alt: string } | null>(null);

  useEffect(() => {
    if (post.category_id) {
      fetchCategory(post.category_id);
    }
    fetchInteractiveElements();
  }, [post.category_id, post.id]);

  useEffect(() => {
    if (post.content.includes('data-pin-do')) {
      const timer = setTimeout(() => {
        waitForPinterestAndBuild();
      }, 500);

      return () => clearTimeout(timer);
    }
  }, [post.content, post.id]);

  useEffect(() => {
    const handleImageClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'IMG' && target.closest('.blog-content')) {
        const img = target as HTMLImageElement;
        setLightboxImage({ src: img.src, alt: img.alt || 'Blog image' });
      }
    };

    document.addEventListener('click', handleImageClick);
    return () => document.removeEventListener('click', handleImageClick);
  }, []);

  const fetchInteractiveElements = async () => {
    const [quizResult, pollResult] = await Promise.all([
      supabase.from('post_quizzes').select('id').eq('post_id', post.id).maybeSingle(),
      supabase.from('post_polls').select('id').eq('post_id', post.id).maybeSingle()
    ]);
    setQuizId(quizResult.data?.id || null);
    setPollId(pollResult.data?.id || null);
  };

  const fetchCategory = async (categoryId: string) => {
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('id', categoryId)
      .maybeSingle();

    if (!error && data) {
      setCategory(data);
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <>
      <ReadingProgress />
      <BackToTop />
      {lightboxImage && (
        <ImageLightbox
          src={lightboxImage.src}
          alt={lightboxImage.alt}
          onClose={() => setLightboxImage(null)}
        />
      )}
      <article className="relative min-h-screen bg-gradient-to-b from-white via-pink-50/20 to-white py-8 sm:py-12 md:py-16 overflow-hidden">
        <div className="absolute top-0 right-0 w-48 sm:w-72 md:w-96 h-48 sm:h-72 md:h-96 bg-gradient-to-bl from-pink-100/20 to-transparent rounded-bl-[100px] sm:rounded-bl-[150px] md:rounded-bl-[200px]"></div>
        <div className="absolute bottom-0 left-0 w-48 sm:w-72 md:w-96 h-48 sm:h-72 md:h-96 bg-gradient-to-tr from-rose-100/20 to-transparent rounded-tr-[100px] sm:rounded-tr-[150px] md:rounded-tr-[200px]"></div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <Breadcrumb items={[{ label: 'Blog', path: '/blog' }, { label: post.title }]} />

          <button
            onClick={onBack}
            className="group flex items-center space-x-2 text-pink-500 hover:text-pink-600 mb-6 sm:mb-8 md:mb-12 transition-all duration-300"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-pink-200/30 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <ArrowLeft className="relative w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            </div>
            <span className="font-light tracking-wide text-sm sm:text-base">Back to Stories</span>
          </button>

        {post.image_url && (
          <div className="relative mb-6 sm:mb-8 md:mb-12">
            <div className="absolute -top-2 sm:-top-4 -left-2 sm:-left-4 w-12 sm:w-20 md:w-24 h-12 sm:h-20 md:h-24 border-l-2 border-t-2 border-pink-200/50 hidden sm:block"></div>
            <div className="absolute -bottom-2 sm:-bottom-4 -right-2 sm:-right-4 w-12 sm:w-20 md:w-24 h-12 sm:h-20 md:h-24 border-r-2 border-b-2 border-rose-200/50 hidden sm:block"></div>
            <div className="aspect-video rounded-xl sm:rounded-2xl overflow-hidden shadow-xl sm:shadow-2xl cursor-pointer group">
              <img
                src={post.image_url}
                alt={post.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
            </div>
          </div>
        )}

        <div className="relative bg-white rounded-2xl sm:rounded-3xl shadow-lg sm:shadow-xl p-5 sm:p-8 md:p-16 border border-pink-100">
          <div className="absolute top-0 left-0 w-10 sm:w-16 md:w-20 h-10 sm:h-16 md:h-20 border-l-2 border-t-2 border-pink-200/30 rounded-tl-2xl sm:rounded-tl-3xl hidden sm:block"></div>
          <div className="absolute bottom-0 right-0 w-10 sm:w-16 md:w-20 h-10 sm:h-16 md:h-20 border-r-2 border-b-2 border-rose-200/30 rounded-br-2xl sm:rounded-br-3xl hidden sm:block"></div>

          {category && (
            <div className="flex items-center space-x-2 mb-4 sm:mb-6">
              <Tag className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-pink-400" />
              <span className="px-3 sm:px-4 py-1 sm:py-1.5 bg-gradient-to-r from-pink-50 to-rose-50 text-pink-600 rounded-full text-xs sm:text-sm font-light tracking-wide border border-pink-100">
                {category.name}
              </span>
            </div>
          )}

          <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-6xl font-serif font-bold text-gray-900 mb-4 sm:mb-6 leading-tight">
            {post.title}
          </h1>

          <div className="w-16 sm:w-20 md:w-24 h-0.5 bg-gradient-to-r from-pink-300 to-transparent mb-6 sm:mb-8"></div>

          <div className="flex items-center text-gray-500 mb-8 sm:mb-10 md:mb-12 pb-6 sm:pb-8 border-b border-pink-100 text-sm sm:text-base">
            <Calendar className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-pink-400" />
            <time className="font-light tracking-wide">{formatDate(post.published_at)}</time>
          </div>

          <div className="prose prose-sm sm:prose-base md:prose-lg prose-slate max-w-none">
            <div
              className="blog-content text-gray-700 text-base sm:text-lg leading-relaxed break-words"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </div>

          <style>{`
            .blog-content strong {
              font-weight: 700;
              color: rgb(30 41 59);
            }

            .blog-content em {
              font-style: italic;
            }

            .blog-content u {
              text-decoration: underline;
            }

            .blog-content h1 {
              font-size: 2em;
              font-weight: 700;
              margin: 0.67em 0;
              color: rgb(15 23 42);
            }

            .blog-content h2 {
              font-size: 1.5em;
              font-weight: 700;
              margin: 0.75em 0;
              color: rgb(15 23 42);
            }

            .blog-content p {
              margin: 1em 0;
            }

            .blog-content ul,
            .blog-content ol {
              margin: 1em 0;
              padding-left: 1.5em;
            }

            .blog-content li {
              margin: 0.5em 0;
            }

            .blog-content a {
              color: rgb(59 130 246);
              text-decoration: underline;
            }

            .blog-content a:hover {
              color: rgb(37 99 235);
            }

            .blog-content img {
              max-width: 100%;
              height: auto;
              border-radius: 8px;
              margin: 16px 0;
              cursor: pointer;
              transition: transform 0.3s ease;
            }

            .blog-content img:hover {
              transform: scale(1.02);
            }

            .blog-content blockquote {
              border-left: 4px solid rgb(226 232 240);
              padding-left: 1em;
              margin: 1em 0;
              color: rgb(100 116 139);
              font-style: italic;
            }

            .blog-content .pinterest-embed-container {
              margin: 24px auto !important;
              text-align: center !important;
              max-width: 600px !important;
              display: block !important;
            }

            .blog-content .pinterest-embed-container span[data-pin-log="embed_pin"] {
              display: inline-block !important;
            }

            .blog-content .pinterest-embed-container iframe {
              max-width: 100% !important;
              margin: 0 auto !important;
            }
          `}</style>

          {quizId && <QuizBlock quizId={quizId} />}
          {pollId && <PollBlock pollId={pollId} />}
        </div>
      </div>
    </article>
    </>
  );
}
