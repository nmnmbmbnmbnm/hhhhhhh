import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: '/', label: 'Home' },
    { href: '/blog', label: 'Blog' },
    { href: '/about', label: 'About' },
  ];

  return (
    <header className="bg-white/95 backdrop-blur-sm sticky top-0 z-50 border-b-2 border-pink-100 shadow-lg">
      <div className="absolute top-0 right-0 w-32 sm:w-48 h-32 sm:h-48 bg-gradient-to-bl from-pink-100/40 to-transparent rounded-bl-[100px] sm:rounded-bl-[150px]"></div>
      <div className="absolute top-0 left-0 w-16 sm:w-32 h-16 sm:h-32 border-l-2 border-t-2 border-pink-200/40 hidden sm:block"></div>
      <div className="absolute bottom-0 right-1/4 w-16 sm:w-24 h-16 sm:h-24 border-r border-b border-rose-200/30 rounded-br-full hidden sm:block"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="flex items-center justify-between py-4 sm:py-6">
          <Link to="/" className="relative pb-3 sm:pb-4 cursor-pointer">
            <h1 className="text-2xl sm:text-3xl md:text-4xl tracking-tight" style={{ fontFamily: "'Dancing Script', cursive" }}>
              <span className="text-pink-400 font-bold">Woman</span>
              <span className="text-gray-800 font-bold">thoughts</span>
            </h1>
            <svg className="absolute bottom-0 left-0 w-full h-3 sm:h-4" viewBox="0 0 300 16" preserveAspectRatio="none">
              <path d="M 0 4 Q 80 14, 160 8 T 300 10" fill="none" stroke="#f9a8d4" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </Link>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden relative p-2 text-gray-700 hover:text-pink-500 transition-colors"
            aria-label="Toggle menu"
          >
            <div className={`transform transition-transform duration-300 ${mobileMenuOpen ? 'rotate-180' : ''}`}>
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </div>
          </button>

          <nav className="hidden md:flex items-center space-x-2">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className="relative px-5 py-2.5 text-gray-700 font-light tracking-wide group overflow-hidden rounded-full"
              >
                <span className="relative z-10 transition-colors duration-300 group-hover:text-white">{link.label}</span>
                <span className="absolute inset-0 bg-gradient-to-r from-pink-400 to-rose-400 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ease-out origin-left rounded-full"></span>
                <span className="absolute inset-0 bg-pink-50 opacity-0 group-hover:opacity-0 scale-100 group-hover:scale-150 transition-all duration-300 rounded-full"></span>
              </Link>
            ))}
          </nav>
        </div>

        <div
          className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out ${
            mobileMenuOpen ? 'max-h-96 opacity-100 pb-4' : 'max-h-0 opacity-0'
          }`}
        >
          <nav className="flex flex-col space-y-2">
            {navLinks.map((link, index) => (
              <Link
                key={link.href}
                to={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="relative px-5 py-3 text-gray-700 font-light tracking-wide group overflow-hidden rounded-xl bg-pink-50/50 hover:bg-gradient-to-r hover:from-pink-400 hover:to-rose-400 hover:text-white transition-all duration-300"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <span className="relative z-10">{link.label}</span>
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
}
