export default function LoadingSkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <article
          key={i}
          className="bg-white rounded-xl sm:rounded-2xl overflow-hidden shadow-md"
        >
          <div className="aspect-video bg-gradient-to-r from-pink-100 via-pink-50 to-pink-100 animate-shimmer relative overflow-hidden">
            <div className="absolute inset-0 shimmer-gradient"></div>
          </div>

          <div className="p-4 sm:p-6">
            <div className="mb-3">
              <div className="h-6 w-24 bg-gradient-to-r from-pink-100 via-pink-50 to-pink-100 rounded-full animate-shimmer relative overflow-hidden">
                <div className="absolute inset-0 shimmer-gradient"></div>
              </div>
            </div>

            <div className="mb-3">
              <div className="h-6 w-3/4 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 rounded animate-shimmer relative overflow-hidden mb-2">
                <div className="absolute inset-0 shimmer-gradient"></div>
              </div>
              <div className="h-6 w-1/2 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 rounded animate-shimmer relative overflow-hidden">
                <div className="absolute inset-0 shimmer-gradient"></div>
              </div>
            </div>

            <div className="w-12 h-0.5 bg-gradient-to-r from-pink-200 to-transparent mb-3"></div>

            <div className="space-y-2 mb-5">
              <div className="h-4 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 rounded animate-shimmer relative overflow-hidden">
                <div className="absolute inset-0 shimmer-gradient"></div>
              </div>
              <div className="h-4 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 rounded animate-shimmer relative overflow-hidden">
                <div className="absolute inset-0 shimmer-gradient"></div>
              </div>
              <div className="h-4 w-2/3 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 rounded animate-shimmer relative overflow-hidden">
                <div className="absolute inset-0 shimmer-gradient"></div>
              </div>
            </div>

            <div className="h-4 w-32 bg-gradient-to-r from-gray-200 via-gray-100 to-gray-200 rounded animate-shimmer relative overflow-hidden">
              <div className="absolute inset-0 shimmer-gradient"></div>
            </div>
          </div>
        </article>
      ))}

      <style>{`
        @keyframes shimmer {
          0% {
            background-position: -1000px 0;
          }
          100% {
            background-position: 1000px 0;
          }
        }

        .animate-shimmer {
          animation: shimmer 2s infinite linear;
          background-size: 1000px 100%;
        }

        .shimmer-gradient {
          background: linear-gradient(
            90deg,
            transparent 0%,
            rgba(255, 255, 255, 0.6) 50%,
            transparent 100%
          );
          animation: shimmer 2s infinite linear;
          background-size: 1000px 100%;
        }
      `}</style>
    </div>
  );
}
