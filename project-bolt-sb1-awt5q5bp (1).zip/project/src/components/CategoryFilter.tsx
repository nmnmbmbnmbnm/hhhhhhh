import { Category } from '../lib/supabase';

type CategoryFilterProps = {
  categories: Category[];
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
};

export default function CategoryFilter({ categories, selectedCategory, onSelectCategory }: CategoryFilterProps) {
  return (
    <div className="flex flex-wrap gap-2 sm:gap-3 md:gap-4 justify-center mb-8 sm:mb-12 md:mb-16 px-2">
      <button
        onClick={() => onSelectCategory(null)}
        className={`relative px-4 sm:px-6 md:px-8 py-2 sm:py-2.5 rounded-full font-light tracking-wider text-sm sm:text-base transition-all duration-300 ${
          selectedCategory === null
            ? 'bg-gradient-to-r from-pink-400 via-rose-400 to-pink-500 text-white shadow-lg scale-105'
            : 'bg-white text-gray-700 hover:bg-gradient-to-r hover:from-pink-50 hover:to-rose-50 border border-pink-200 hover:border-pink-300'
        }`}
      >
        {selectedCategory === null && (
          <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-rose-400 rounded-full blur-md opacity-50"></div>
        )}
        <span className="relative">All Topics</span>
      </button>
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onSelectCategory(category.id)}
          className={`relative px-4 sm:px-6 md:px-8 py-2 sm:py-2.5 rounded-full font-light tracking-wider text-sm sm:text-base transition-all duration-300 ${
            selectedCategory === category.id
              ? 'bg-gradient-to-r from-pink-400 via-rose-400 to-pink-500 text-white shadow-lg scale-105'
              : 'bg-white text-gray-700 hover:bg-gradient-to-r hover:from-pink-50 hover:to-rose-50 border border-pink-200 hover:border-pink-300'
          }`}
        >
          {selectedCategory === category.id && (
            <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-rose-400 rounded-full blur-md opacity-50"></div>
          )}
          <span className="relative">{category.name}</span>
        </button>
      ))}
    </div>
  );
}
