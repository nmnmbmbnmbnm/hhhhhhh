import { useState, useEffect } from 'react';
import { CheckCircle2, XCircle, Trophy, RotateCcw, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';

type QuizOption = {
  id: string;
  option_text: string;
  is_correct: boolean;
  order_index: number;
};

type QuizQuestion = {
  id: string;
  question_text: string;
  order_index: number;
  options: QuizOption[];
};

type Quiz = {
  id: string;
  title: string;
  description: string;
  questions: QuizQuestion[];
};

type QuizBlockProps = {
  quizId: string;
};

export default function QuizBlock({ quizId }: QuizBlockProps) {
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [revealedQuestions, setRevealedQuestions] = useState<Set<string>>(new Set());
  const [sessionId] = useState(() => `quiz_${Date.now()}_${Math.random().toString(36).slice(2)}`);

  useEffect(() => {
    fetchQuiz();
  }, [quizId]);

  const fetchQuiz = async () => {
    setLoading(true);
    const { data: quizData, error: quizError } = await supabase
      .from('post_quizzes')
      .select('*')
      .eq('id', quizId)
      .maybeSingle();

    if (quizError || !quizData) {
      setLoading(false);
      return;
    }

    const { data: questionsData } = await supabase
      .from('quiz_questions')
      .select('*')
      .eq('quiz_id', quizId)
      .order('order_index');

    if (!questionsData) {
      setLoading(false);
      return;
    }

    const questionIds = questionsData.map(q => q.id);
    const { data: optionsData } = await supabase
      .from('quiz_options')
      .select('*')
      .in('question_id', questionIds)
      .order('order_index');

    const questions = questionsData.map(q => ({
      ...q,
      options: (optionsData || []).filter(o => o.question_id === q.id)
    }));

    setQuiz({
      ...quizData,
      questions
    });
    setLoading(false);
  };

  const handleSelectAnswer = (questionId: string, optionId: string) => {
    if (revealedQuestions.has(questionId)) return;

    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionId
    }));

    setRevealedQuestions(prev => new Set([...prev, questionId]));
  };

  const handleNextQuestion = () => {
    if (quiz && currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = async () => {
    if (!quiz) return;

    const score = quiz.questions.reduce((acc, q) => {
      const selectedOption = q.options.find(o => o.id === selectedAnswers[q.id]);
      return acc + (selectedOption?.is_correct ? 1 : 0);
    }, 0);

    await supabase.from('quiz_responses').insert({
      quiz_id: quizId,
      session_id: sessionId,
      score,
      total_questions: quiz.questions.length
    });

    setShowResults(true);
  };

  const handleRetry = () => {
    setCurrentQuestion(0);
    setSelectedAnswers({});
    setRevealedQuestions(new Set());
    setShowResults(false);
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8 my-8 animate-pulse">
        <div className="h-6 bg-amber-200 rounded w-1/3 mb-4"></div>
        <div className="h-4 bg-amber-100 rounded w-2/3"></div>
      </div>
    );
  }

  if (!quiz || quiz.questions.length === 0) {
    return null;
  }

  const score = quiz.questions.reduce((acc, q) => {
    const selectedOption = q.options.find(o => o.id === selectedAnswers[q.id]);
    return acc + (selectedOption?.is_correct ? 1 : 0);
  }, 0);
  const percentage = Math.round((score / quiz.questions.length) * 100);

  if (showResults) {
    return (
      <div className="bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 rounded-2xl p-8 my-8 border border-amber-200 shadow-lg">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full mb-6 shadow-lg">
            <Trophy className="w-10 h-10 text-white" />
          </div>

          <h3 className="text-2xl font-bold text-gray-900 mb-2">{quiz.title} - Eredmeny</h3>

          <div className="text-6xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent my-6">
            {score}/{quiz.questions.length}
          </div>

          <div className="w-full bg-gray-200 rounded-full h-4 mb-4 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-1000 ease-out"
              style={{
                width: `${percentage}%`,
                background: percentage >= 70
                  ? 'linear-gradient(90deg, #22c55e, #16a34a)'
                  : percentage >= 40
                    ? 'linear-gradient(90deg, #f59e0b, #d97706)'
                    : 'linear-gradient(90deg, #ef4444, #dc2626)'
              }}
            ></div>
          </div>

          <p className="text-gray-600 mb-6">
            {percentage >= 80 ? 'Kivalo teljesitmeny!' :
             percentage >= 60 ? 'Jo munka!' :
             percentage >= 40 ? 'Nem rossz, de van meg hova fejlodni!' :
             'Probald ujra, biztosan jobban fog menni!'}
          </p>

          <button
            onClick={handleRetry}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-medium hover:from-amber-600 hover:to-orange-600 transition-all shadow-md hover:shadow-lg"
          >
            <RotateCcw className="w-5 h-5" />
            Ujrakezdes
          </button>
        </div>
      </div>
    );
  }

  const question = quiz.questions[currentQuestion];
  const isRevealed = revealedQuestions.has(question.id);
  const selectedOptionId = selectedAnswers[question.id];

  return (
    <div className="bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 rounded-2xl p-6 sm:p-8 my-8 border border-amber-200 shadow-lg">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-gray-900">{quiz.title}</h3>
        <span className="px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-sm font-medium">
          {currentQuestion + 1} / {quiz.questions.length}
        </span>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-2 mb-8">
        <div
          className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full transition-all duration-500"
          style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
        ></div>
      </div>

      <p className="text-lg font-medium text-gray-800 mb-6">{question.question_text}</p>

      <div className="space-y-3 mb-6">
        {question.options.map((option) => {
          const isSelected = selectedOptionId === option.id;
          const isCorrect = option.is_correct;

          let optionClass = 'border-gray-200 bg-white hover:border-amber-300 hover:bg-amber-50';

          if (isRevealed) {
            if (isCorrect) {
              optionClass = 'border-green-400 bg-green-50';
            } else if (isSelected && !isCorrect) {
              optionClass = 'border-red-400 bg-red-50';
            } else {
              optionClass = 'border-gray-200 bg-gray-50 opacity-60';
            }
          } else if (isSelected) {
            optionClass = 'border-amber-400 bg-amber-50';
          }

          return (
            <button
              key={option.id}
              onClick={() => handleSelectAnswer(question.id, option.id)}
              disabled={isRevealed}
              className={`w-full p-4 rounded-xl border-2 text-left transition-all duration-300 ${optionClass} ${!isRevealed ? 'cursor-pointer' : 'cursor-default'}`}
            >
              <div className="flex items-center justify-between">
                <span className={`font-medium ${isRevealed && isCorrect ? 'text-green-700' : isRevealed && isSelected && !isCorrect ? 'text-red-700' : 'text-gray-700'}`}>
                  {option.option_text}
                </span>
                {isRevealed && isCorrect && (
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                )}
                {isRevealed && isSelected && !isCorrect && (
                  <XCircle className="w-6 h-6 text-red-500" />
                )}
              </div>
            </button>
          );
        })}
      </div>

      {isRevealed && (
        <button
          onClick={handleNextQuestion}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-xl font-medium hover:from-amber-600 hover:to-orange-600 transition-all shadow-md hover:shadow-lg"
        >
          {currentQuestion < quiz.questions.length - 1 ? (
            <>
              Kovetkezo kerdes
              <ChevronRight className="w-5 h-5" />
            </>
          ) : (
            <>
              Eredmeny megtekintese
              <Trophy className="w-5 h-5" />
            </>
          )}
        </button>
      )}
    </div>
  );
}
