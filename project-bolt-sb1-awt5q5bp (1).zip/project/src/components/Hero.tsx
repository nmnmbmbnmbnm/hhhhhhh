import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Calendar, User, Clock, Heart, MessageCircle, Share2 } from 'lucide-react';
import { supabase, Post } from '../lib/supabase';
import RippleButton from './RippleButton';

export default function Hero() {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slideState, setSlideState] = useState<'entering' | 'visible' | 'exiting'>('visible');
  const [featuredBlogs, setFeaturedBlogs] = useState<Post[]>([]);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    fetchPosts();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('published', true)
        .order('created_at', { ascending: false })
        .limit(4);

      if (error) throw error;
      setFeaturedBlogs(data || []);
    } catch (err) {
      console.error('Failed to fetch posts:', err);
    }
  };

  useEffect(() => {
    if (featuredBlogs.length === 0) return;

    const interval = setInterval(() => {
      setSlideState('exiting');
      setTimeout(() => {
        setCurrentSlide((prev) => (prev + 1) % featuredBlogs.length);
        setSlideState('entering');
        setTimeout(() => {
          setSlideState('visible');
        }, 50);
      }, 600);
    }, 4000);

    return () => clearInterval(interval);
  }, [featuredBlogs.length]);

  const getSlideClasses = () => {
    switch (slideState) {
      case 'entering':
        return 'translate-x-[-100%] opacity-0';
      case 'exiting':
        return 'translate-x-[100%] opacity-0 rotate-y-12';
      default:
        return 'translate-x-0 opacity-100';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  if (featuredBlogs.length === 0) {
    return (
      <section id="home" className="relative bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 py-12 sm:py-16 md:py-24 overflow-hidden">
        <div className="absolute top-0 right-0 w-48 sm:w-72 md:w-96 h-48 sm:h-72 md:h-96 bg-gradient-to-bl from-pink-200/30 to-transparent rounded-bl-[100px] sm:rounded-bl-[150px] md:rounded-bl-[200px]"></div>
        <div className="absolute bottom-0 left-0 w-40 sm:w-60 md:w-80 h-40 sm:h-60 md:h-80 bg-gradient-to-tr from-rose-200/30 to-transparent rounded-tr-[100px] sm:rounded-tr-[150px] md:rounded-tr-[200px]"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <div className="mb-4 sm:mb-6 flex justify-center">
              <div className="inline-block relative max-w-3xl">
                <div className="absolute -top-2 sm:-top-4 -left-2 sm:-left-4 w-10 sm:w-16 md:w-20 h-10 sm:h-16 md:h-20 border-l-2 border-t-2 border-pink-400/40"></div>
                <div className="absolute -bottom-2 sm:-bottom-4 -right-2 sm:-right-4 w-10 sm:w-16 md:w-20 h-10 sm:h-16 md:h-20 border-r-2 border-b-2 border-rose-400/40"></div>
                <blockquote className="px-4 sm:px-8 md:px-10 py-4 sm:py-6">
                  <p
                    className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 bg-clip-text text-transparent leading-tight"
                    style={{ fontFamily: "'Dancing Script', cursive" }}
                  >
                    "A woman is the full circle. Within her is the power to create, nurture, and transform."
                  </p>
                  <footer className="mt-4 sm:mt-6 text-gray-500 font-light tracking-widest text-xs sm:text-sm uppercase">
                    - Diane Mariechild
                  </footer>
                </blockquote>
              </div>
            </div>

            <div className="relative inline-block">
              <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-pink-300 to-transparent"></div>
              <p className="text-base sm:text-lg md:text-xl text-gray-600 max-w-2xl mx-auto my-6 sm:my-8 md:my-10 leading-relaxed font-light tracking-wide px-4 sm:px-8">
                A space celebrating feminine strength, wisdom, and the beauty of shared stories.
              </p>
              <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-rose-300 to-transparent"></div>
            </div>

            <div className="mt-8 sm:mt-12">
              <p className="text-gray-500 text-sm">No stories yet. Check back soon!</p>
            </div>
          </div>
        </div>
      </section>
    );
  }

  const blog = featuredBlogs[currentSlide];

  return (
    <section id="home" className="relative bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 py-12 sm:py-16 md:py-24 overflow-hidden">
      <div
        className="absolute top-0 right-0 w-48 sm:w-72 md:w-96 h-48 sm:h-72 md:h-96 bg-gradient-to-bl from-pink-200/30 to-transparent rounded-bl-[100px] sm:rounded-bl-[150px] md:rounded-bl-[200px] transition-transform duration-75"
        style={{ transform: `translateY(${scrollY * 0.3}px)` }}
      ></div>
      <div
        className="absolute bottom-0 left-0 w-40 sm:w-60 md:w-80 h-40 sm:h-60 md:h-80 bg-gradient-to-tr from-rose-200/30 to-transparent rounded-tr-[100px] sm:rounded-tr-[150px] md:rounded-tr-[200px] transition-transform duration-75"
        style={{ transform: `translateY(${scrollY * -0.2}px)` }}
      ></div>

      <div
        className="absolute top-4 sm:top-8 right-4 sm:right-8 w-16 sm:w-24 md:w-32 h-16 sm:h-24 md:h-32 border-r-2 border-t-2 border-pink-300/50 rounded-tr-2xl sm:rounded-tr-3xl hidden sm:block transition-transform duration-75"
        style={{ transform: `translateY(${scrollY * 0.4}px)` }}
      ></div>
      <div
        className="absolute bottom-4 sm:bottom-8 left-4 sm:left-8 w-20 sm:w-32 md:w-40 h-20 sm:h-32 md:h-40 border-l-2 border-b-2 border-rose-300/50 rounded-bl-2xl sm:rounded-bl-3xl hidden sm:block transition-transform duration-75"
        style={{ transform: `translateY(${scrollY * -0.3}px)` }}
      ></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          <div className="mb-4 sm:mb-6 flex justify-center">
            <div className="inline-block relative max-w-3xl">
              <div className="absolute -top-2 sm:-top-4 -left-2 sm:-left-4 w-10 sm:w-16 md:w-20 h-10 sm:h-16 md:h-20 border-l-2 border-t-2 border-pink-400/40"></div>
              <div className="absolute -bottom-2 sm:-bottom-4 -right-2 sm:-right-4 w-10 sm:w-16 md:w-20 h-10 sm:h-16 md:h-20 border-r-2 border-b-2 border-rose-400/40"></div>
              <blockquote className="px-4 sm:px-8 md:px-10 py-4 sm:py-6">
                <p
                  className="text-2xl sm:text-3xl md:text-5xl lg:text-6xl bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 bg-clip-text text-transparent leading-tight"
                  style={{ fontFamily: "'Dancing Script', cursive" }}
                >
                  "A woman is the full circle. Within her is the power to create, nurture, and transform."
                </p>
                <footer className="mt-4 sm:mt-6 text-gray-500 font-light tracking-widest text-xs sm:text-sm uppercase">
                  - Diane Mariechild
                </footer>
              </blockquote>
            </div>
          </div>

          <div className="relative inline-block">
            <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-pink-300 to-transparent"></div>
            <p className="text-base sm:text-lg md:text-xl text-gray-600 max-w-2xl mx-auto my-6 sm:my-8 md:my-10 leading-relaxed font-light tracking-wide px-4 sm:px-8">
              A space celebrating feminine strength, wisdom, and the beauty of shared stories.
            </p>
            <div className="absolute bottom-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-rose-300 to-transparent"></div>
          </div>

          <div className="mt-6 sm:mt-8">
            <Link
              to="/blog"
              className="group relative inline-block"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-pink-400 to-rose-400 rounded-full blur-lg opacity-50 group-hover:opacity-75 transition-opacity"></div>
              <span className="relative inline-flex items-center bg-gradient-to-r from-pink-400 via-rose-400 to-pink-500 text-white px-6 sm:px-10 py-3 sm:py-4 rounded-full font-light tracking-widest text-sm sm:text-base hover:shadow-2xl hover:scale-105 transition-all duration-300">
                Explore Stories
              </span>
            </Link>
          </div>

          <div className="mt-8 sm:mt-12 flex justify-center">
            <div className="relative w-full max-w-xs sm:max-w-md perspective-1000">
              <div
                className={`transform transition-all duration-600 ease-in-out ${getSlideClasses()}`}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div
                  className="bg-white rounded-lg shadow-2xl overflow-hidden border border-gray-100 cursor-pointer hover:shadow-3xl hover:scale-105 transition-all duration-300"
                  onClick={() => navigate(`/blog/${blog.id}`)}
                >
                  {blog.image_url && (
                    <div className="relative h-32 overflow-hidden">
                      <img
                        src={blog.image_url}
                        alt={blog.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                      <div className="absolute bottom-2 left-3">
                        <span className="bg-pink-500 text-white text-[9px] px-2 py-0.5 rounded-full font-medium">
                          {blog.category}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="p-4">
                    <h3 className="text-sm font-serif font-bold text-gray-800 mb-2 leading-tight line-clamp-2">
                      {blog.title}
                    </h3>

                    <div className="flex items-center gap-3 text-[10px] text-gray-500 mb-3">
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" />
                        {blog.author}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDate(blog.created_at)}
                      </span>
                    </div>

                    <p className="text-[11px] text-gray-600 leading-relaxed line-clamp-4 mb-3">
                      {blog.excerpt}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-center gap-1.5 mt-4">
                {featuredBlogs.map((_, index) => (
                  <div
                    key={index}
                    className={`h-1 rounded-full transition-all duration-300 ${
                      index === currentSlide
                        ? 'bg-pink-400 w-4'
                        : 'bg-gray-300 w-1'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
