import { useState, useEffect } from 'react';
import { Plus, Trash2, GripVertical, CheckCircle2, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

type QuizOption = {
  id?: string;
  option_text: string;
  is_correct: boolean;
  order_index: number;
};

type QuizQuestion = {
  id?: string;
  question_text: string;
  order_index: number;
  options: QuizOption[];
};

type Quiz = {
  id?: string;
  title: string;
  description: string;
  questions: QuizQuestion[];
};

type QuizEditorProps = {
  postId: string;
  onClose: () => void;
};

export default function QuizEditor({ postId, onClose }: QuizEditorProps) {
  const [quiz, setQuiz] = useState<Quiz>({
    title: '',
    description: '',
    questions: []
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchExistingQuiz();
  }, [postId]);

  const fetchExistingQuiz = async () => {
    setLoading(true);
    const { data: quizData } = await supabase
      .from('post_quizzes')
      .select('*')
      .eq('post_id', postId)
      .maybeSingle();

    if (quizData) {
      const { data: questionsData } = await supabase
        .from('quiz_questions')
        .select('*')
        .eq('quiz_id', quizData.id)
        .order('order_index');

      const questionIds = (questionsData || []).map(q => q.id);
      const { data: optionsData } = await supabase
        .from('quiz_options')
        .select('*')
        .in('question_id', questionIds.length > 0 ? questionIds : [''])
        .order('order_index');

      const questions = (questionsData || []).map(q => ({
        ...q,
        options: (optionsData || []).filter(o => o.question_id === q.id)
      }));

      setQuiz({
        ...quizData,
        questions
      });
    }

    setLoading(false);
  };

  const addQuestion = () => {
    setQuiz(prev => ({
      ...prev,
      questions: [
        ...prev.questions,
        {
          question_text: '',
          order_index: prev.questions.length,
          options: [
            { option_text: '', is_correct: true, order_index: 0 },
            { option_text: '', is_correct: false, order_index: 1 }
          ]
        }
      ]
    }));
  };

  const removeQuestion = (index: number) => {
    setQuiz(prev => ({
      ...prev,
      questions: prev.questions.filter((_, i) => i !== index).map((q, i) => ({ ...q, order_index: i }))
    }));
  };

  const updateQuestion = (index: number, text: string) => {
    setQuiz(prev => ({
      ...prev,
      questions: prev.questions.map((q, i) => i === index ? { ...q, question_text: text } : q)
    }));
  };

  const addOption = (questionIndex: number) => {
    setQuiz(prev => ({
      ...prev,
      questions: prev.questions.map((q, i) =>
        i === questionIndex
          ? {
              ...q,
              options: [...q.options, { option_text: '', is_correct: false, order_index: q.options.length }]
            }
          : q
      )
    }));
  };

  const removeOption = (questionIndex: number, optionIndex: number) => {
    setQuiz(prev => ({
      ...prev,
      questions: prev.questions.map((q, i) =>
        i === questionIndex
          ? {
              ...q,
              options: q.options.filter((_, oi) => oi !== optionIndex).map((o, oi) => ({ ...o, order_index: oi }))
            }
          : q
      )
    }));
  };

  const updateOption = (questionIndex: number, optionIndex: number, text: string) => {
    setQuiz(prev => ({
      ...prev,
      questions: prev.questions.map((q, qi) =>
        qi === questionIndex
          ? {
              ...q,
              options: q.options.map((o, oi) => oi === optionIndex ? { ...o, option_text: text } : o)
            }
          : q
      )
    }));
  };

  const setCorrectAnswer = (questionIndex: number, optionIndex: number) => {
    setQuiz(prev => ({
      ...prev,
      questions: prev.questions.map((q, qi) =>
        qi === questionIndex
          ? {
              ...q,
              options: q.options.map((o, oi) => ({ ...o, is_correct: oi === optionIndex }))
            }
          : q
      )
    }));
  };

  const handleSave = async () => {
    if (!quiz.title.trim()) {
      setError('Add meg a kviz cimet');
      return;
    }

    if (quiz.questions.length === 0) {
      setError('Adj hozza legalabb egy kerdest');
      return;
    }

    for (const q of quiz.questions) {
      if (!q.question_text.trim()) {
        setError('Minden kerdes szovege kotelezo');
        return;
      }
      if (q.options.length < 2) {
        setError('Minden kerdesnek legalabb 2 valaszlehetosege legyen');
        return;
      }
      for (const o of q.options) {
        if (!o.option_text.trim()) {
          setError('Minden valaszlehetoseg szovege kotelezo');
          return;
        }
      }
    }

    setSaving(true);
    setError('');

    try {
      let quizId = quiz.id;

      if (quizId) {
        await supabase
          .from('post_quizzes')
          .update({ title: quiz.title, description: quiz.description })
          .eq('id', quizId);

        const { data: existingQuestions } = await supabase
          .from('quiz_questions')
          .select('id')
          .eq('quiz_id', quizId);

        if (existingQuestions && existingQuestions.length > 0) {
          await supabase
            .from('quiz_questions')
            .delete()
            .eq('quiz_id', quizId);
        }
      } else {
        const { data: newQuiz, error: quizError } = await supabase
          .from('post_quizzes')
          .insert({ post_id: postId, title: quiz.title, description: quiz.description })
          .select()
          .single();

        if (quizError) throw quizError;
        quizId = newQuiz.id;
      }

      for (const question of quiz.questions) {
        const { data: newQuestion, error: questionError } = await supabase
          .from('quiz_questions')
          .insert({
            quiz_id: quizId,
            question_text: question.question_text,
            order_index: question.order_index
          })
          .select()
          .single();

        if (questionError) throw questionError;

        const optionsToInsert = question.options.map(o => ({
          question_id: newQuestion.id,
          option_text: o.option_text,
          is_correct: o.is_correct,
          order_index: o.order_index
        }));

        const { error: optionsError } = await supabase
          .from('quiz_options')
          .insert(optionsToInsert);

        if (optionsError) throw optionsError;
      }

      onClose();
    } catch {
      setError('Hiba tortent a mentes soran');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!quiz.id) {
      onClose();
      return;
    }

    if (!confirm('Biztosan torlod a kvizt?')) return;

    setSaving(true);
    await supabase.from('post_quizzes').delete().eq('id', quiz.id);
    setSaving(false);
    onClose();
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg border border-slate-200 p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-slate-200 rounded w-1/3"></div>
          <div className="h-10 bg-slate-100 rounded"></div>
          <div className="h-32 bg-slate-100 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-slate-200 p-6 max-h-[80vh] overflow-y-auto">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-slate-900">Kviz szerkeszto</h3>
        <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-lg transition">
          <X size={24} className="text-slate-600" />
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Kviz cime *</label>
          <input
            type="text"
            value={quiz.title}
            onChange={(e) => setQuiz(prev => ({ ...prev, title: e.target.value }))}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
            placeholder="Pl.: Mennyire ismered a temat?"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Leiras (opcionalis)</label>
          <input
            type="text"
            value={quiz.description}
            onChange={(e) => setQuiz(prev => ({ ...prev, description: e.target.value }))}
            className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
            placeholder="Rovid leiras a kvizrol"
          />
        </div>

        <div className="border-t border-slate-200 pt-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-slate-800">Kerdesek</h4>
            <button
              type="button"
              onClick={addQuestion}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-amber-500 text-white rounded-lg text-sm font-medium hover:bg-amber-600 transition"
            >
              <Plus size={16} />
              Uj kerdes
            </button>
          </div>

          {quiz.questions.length === 0 ? (
            <div className="text-center py-8 text-slate-500 bg-slate-50 rounded-lg border-2 border-dashed border-slate-200">
              Meg nincs kerdes. Kattints az "Uj kerdes" gombra!
            </div>
          ) : (
            <div className="space-y-6">
              {quiz.questions.map((question, qi) => (
                <div key={qi} className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <div className="flex items-start gap-3 mb-4">
                    <GripVertical size={20} className="text-slate-400 mt-2 cursor-move" />
                    <div className="flex-1">
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {qi + 1}. kerdes
                      </label>
                      <input
                        type="text"
                        value={question.question_text}
                        onChange={(e) => updateQuestion(qi, e.target.value)}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none"
                        placeholder="Ird be a kerdest..."
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeQuestion(qi)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>

                  <div className="ml-8 space-y-2">
                    <label className="block text-sm font-medium text-slate-600 mb-2">
                      Valaszlehetosegek (jelold be a helyes valaszt)
                    </label>
                    {question.options.map((option, oi) => (
                      <div key={oi} className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setCorrectAnswer(qi, oi)}
                          className={`p-1.5 rounded-full transition ${
                            option.is_correct
                              ? 'bg-green-500 text-white'
                              : 'bg-slate-200 text-slate-400 hover:bg-slate-300'
                          }`}
                        >
                          <CheckCircle2 size={16} />
                        </button>
                        <input
                          type="text"
                          value={option.option_text}
                          onChange={(e) => updateOption(qi, oi, e.target.value)}
                          className="flex-1 px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none text-sm"
                          placeholder={`${oi + 1}. valasz`}
                        />
                        {question.options.length > 2 && (
                          <button
                            type="button"
                            onClick={() => removeOption(qi, oi)}
                            className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition"
                          >
                            <X size={16} />
                          </button>
                        )}
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={() => addOption(qi)}
                      className="text-sm text-amber-600 hover:text-amber-700 font-medium mt-2"
                    >
                      + Uj valaszlehetoseg
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center gap-3 pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="flex-1 bg-amber-500 text-white py-2 rounded-lg font-medium hover:bg-amber-600 transition disabled:opacity-50"
          >
            {saving ? 'Mentes...' : 'Kviz mentese'}
          </button>
          {quiz.id && (
            <button
              type="button"
              onClick={handleDelete}
              disabled={saving}
              className="px-4 py-2 bg-red-100 text-red-600 rounded-lg font-medium hover:bg-red-200 transition disabled:opacity-50"
            >
              Torles
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 text-slate-700 rounded-lg font-medium hover:bg-slate-300 transition"
          >
            Megse
          </button>
        </div>
      </div>
    </div>
  );
}
