import { useState, useEffect } from 'react';
import { BarChart3, Check, Users } from 'lucide-react';
import { supabase } from '../lib/supabase';

type PollOption = {
  id: string;
  option_text: string;
  order_index: number;
  vote_count: number;
};

type Poll = {
  id: string;
  question: string;
  allow_multiple: boolean;
  options: PollOption[];
};

type PollBlockProps = {
  pollId: string;
};

const STORAGE_KEY_PREFIX = 'poll_voted_';

export default function PollBlock({ pollId }: PollBlockProps) {
  const [poll, setPoll] = useState<Poll | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasVoted, setHasVoted] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<Set<string>>(new Set());
  const [voting, setVoting] = useState(false);
  const [sessionId] = useState(() => {
    const stored = localStorage.getItem(`poll_session_${pollId}`);
    if (stored) return stored;
    const newId = `poll_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    localStorage.setItem(`poll_session_${pollId}`, newId);
    return newId;
  });

  useEffect(() => {
    fetchPoll();
    checkIfVoted();
  }, [pollId]);

  const fetchPoll = async () => {
    setLoading(true);
    const { data: pollData, error: pollError } = await supabase
      .from('post_polls')
      .select('*')
      .eq('id', pollId)
      .maybeSingle();

    if (pollError || !pollData) {
      setLoading(false);
      return;
    }

    const { data: optionsData } = await supabase
      .from('poll_options')
      .select('*')
      .eq('poll_id', pollId)
      .order('order_index');

    const { data: votesData } = await supabase
      .from('poll_votes')
      .select('option_id')
      .eq('poll_id', pollId);

    const voteCounts: Record<string, number> = {};
    (votesData || []).forEach(vote => {
      voteCounts[vote.option_id] = (voteCounts[vote.option_id] || 0) + 1;
    });

    const options = (optionsData || []).map(o => ({
      ...o,
      vote_count: voteCounts[o.id] || 0
    }));

    setPoll({
      ...pollData,
      options
    });
    setLoading(false);
  };

  const checkIfVoted = () => {
    const voted = localStorage.getItem(`${STORAGE_KEY_PREFIX}${pollId}`);
    setHasVoted(voted === 'true');
  };

  const toggleOption = (optionId: string) => {
    if (hasVoted) return;

    setSelectedOptions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(optionId)) {
        newSet.delete(optionId);
      } else {
        if (!poll?.allow_multiple) {
          newSet.clear();
        }
        newSet.add(optionId);
      }
      return newSet;
    });
  };

  const handleVote = async () => {
    if (selectedOptions.size === 0 || !poll || voting) return;

    setVoting(true);

    const votes = Array.from(selectedOptions).map(optionId => ({
      poll_id: pollId,
      option_id: optionId,
      session_id: sessionId
    }));

    const { error } = await supabase.from('poll_votes').insert(votes);

    if (!error) {
      localStorage.setItem(`${STORAGE_KEY_PREFIX}${pollId}`, 'true');
      setHasVoted(true);
      await fetchPoll();
    }

    setVoting(false);
  };

  if (loading) {
    return (
      <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 my-8 animate-pulse">
        <div className="h-6 bg-blue-200 rounded w-1/2 mb-4"></div>
        <div className="space-y-3">
          <div className="h-12 bg-blue-100 rounded-xl"></div>
          <div className="h-12 bg-blue-100 rounded-xl"></div>
          <div className="h-12 bg-blue-100 rounded-xl"></div>
        </div>
      </div>
    );
  }

  if (!poll || poll.options.length === 0) {
    return null;
  }

  const totalVotes = poll.options.reduce((acc, o) => acc + o.vote_count, 0);

  return (
    <div className="bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50 rounded-2xl p-6 sm:p-8 my-8 border border-blue-200 shadow-lg">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg">
          <BarChart3 className="w-5 h-5 text-white" />
        </div>
        <h3 className="text-xl font-bold text-gray-900">Szavazas</h3>
      </div>

      <p className="text-lg font-medium text-gray-800 mb-6">{poll.question}</p>

      {poll.allow_multiple && !hasVoted && (
        <p className="text-sm text-blue-600 mb-4">Tobb valasz is kivalaszthato</p>
      )}

      <div className="space-y-3 mb-6">
        {poll.options.map((option) => {
          const percentage = totalVotes > 0 ? Math.round((option.vote_count / totalVotes) * 100) : 0;
          const isSelected = selectedOptions.has(option.id);

          if (hasVoted) {
            return (
              <div key={option.id} className="relative overflow-hidden rounded-xl border-2 border-blue-100 bg-white">
                <div
                  className="absolute inset-0 bg-gradient-to-r from-blue-100 to-cyan-100 transition-all duration-1000 ease-out"
                  style={{ width: `${percentage}%` }}
                ></div>
                <div className="relative flex items-center justify-between p-4">
                  <span className="font-medium text-gray-700">{option.option_text}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">{option.vote_count} szavazat</span>
                    <span className="font-bold text-blue-600">{percentage}%</span>
                  </div>
                </div>
              </div>
            );
          }

          return (
            <button
              key={option.id}
              onClick={() => toggleOption(option.id)}
              className={`w-full p-4 rounded-xl border-2 text-left transition-all duration-300 ${
                isSelected
                  ? 'border-blue-400 bg-blue-50'
                  : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-gray-700">{option.option_text}</span>
                {isSelected && (
                  <div className="p-1 bg-blue-500 rounded-full">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {hasVoted ? (
        <div className="flex items-center justify-center gap-2 text-gray-500">
          <Users className="w-5 h-5" />
          <span>Osszesen {totalVotes} szavazat</span>
        </div>
      ) : (
        <button
          onClick={handleVote}
          disabled={selectedOptions.size === 0 || voting}
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-xl font-medium hover:from-blue-600 hover:to-cyan-600 transition-all shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {voting ? 'Szavazas...' : 'Szavazok'}
        </button>
      )}
    </div>
  );
}
