import { useState } from 'react';
import { Calendar, Tag, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Post, Category } from '../lib/supabase';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

type BlogCardProps = {
  post: Post;
  category: Category | null;
  onSelectPost?: (post: Post) => void;
  index?: number;
};

export default function BlogCard({ post, category, onSelectPost, index = 0 }: BlogCardProps) {
  const navigate = useNavigate();
  const { ref, isVisible } = useScrollAnimation();
  const [isSaved, setIsSaved] = useState(false);
  const formatDate = (dateString: string | null) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const handleClick = () => {
    if (onSelectPost) {
      onSelectPost(post);
    } else {
      navigate(`/blog/${post.id}`);
    }
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsSaved(!isSaved);
  };

  return (
    <article
      ref={ref}
      onClick={handleClick}
      className={`relative bg-white rounded-xl sm:rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500 cursor-pointer group ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
      style={{
        transitionDelay: `${index * 100}ms`,
      }}
    >
      <div className="absolute top-0 left-0 w-10 sm:w-16 h-10 sm:h-16 border-l-2 border-t-2 border-pink-200 opacity-0 group-hover:opacity-100 transition-opacity duration-500 hidden sm:block"></div>
      <div className="absolute bottom-0 right-0 w-10 sm:w-16 h-10 sm:h-16 border-r-2 border-b-2 border-rose-200 opacity-0 group-hover:opacity-100 transition-opacity duration-500 hidden sm:block"></div>

      <div className="absolute inset-0 border-2 border-transparent group-hover:border-pink-100 transition-all duration-500 rounded-xl sm:rounded-2xl"></div>

      <div className="aspect-video bg-gradient-to-br from-pink-100 via-rose-50 to-pink-100 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-white/40 to-transparent rounded-bl-full"></div>

        {post.image_url ? (
          <img
            src={post.image_url}
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-pink-300/20 rounded-full blur-xl"></div>
              <Tag className="relative w-16 h-16 text-pink-300" />
            </div>
          </div>
        )}
      </div>

      <div className="p-4 sm:p-6 relative">
        {category && (
          <div className="mb-2 sm:mb-3">
            <span className="inline-block px-3 sm:px-4 py-1 sm:py-1.5 bg-gradient-to-r from-pink-50 to-rose-50 text-pink-600 rounded-full text-xs sm:text-sm font-light tracking-wide border border-pink-100">
              {category.name}
            </span>
          </div>
        )}

        <h3 className="text-lg sm:text-xl font-serif font-bold text-gray-900 mb-2 sm:mb-3 group-hover:text-pink-500 transition-colors line-clamp-2 leading-snug">
          {post.title}
        </h3>

        <div className="w-10 sm:w-12 h-0.5 bg-gradient-to-r from-pink-300 to-transparent mb-2 sm:mb-3 group-hover:w-20 sm:group-hover:w-24 transition-all duration-500"></div>

        <p className="text-gray-600 mb-4 sm:mb-5 line-clamp-3 leading-relaxed font-light text-sm sm:text-base">
          {post.excerpt}
        </p>

        <div className="flex items-center text-xs sm:text-sm text-gray-500 font-light">
          <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4 mr-1.5 sm:mr-2 text-pink-400" />
          <time>{formatDate(post.published_at)}</time>
        </div>

        <button
          onClick={handleSave}
          className={`absolute top-4 right-4 p-2 rounded-full transition-all duration-300 ${
            isSaved
              ? 'bg-pink-500 text-white scale-110'
              : 'bg-white/80 text-gray-400 hover:bg-pink-100 hover:text-pink-500'
          } shadow-lg hover:shadow-xl`}
          aria-label="Save post"
        >
          <Heart
            className={`w-4 h-4 transition-all duration-300 ${
              isSaved ? 'fill-current animate-heartBeat' : ''
            }`}
          />
        </button>

        <style>{`
          @keyframes heartBeat {
            0%, 100% {
              transform: scale(1);
            }
            25% {
              transform: scale(1.3);
            }
            50% {
              transform: scale(1.1);
            }
          }

          .animate-heartBeat {
            animation: heartBeat 0.5s ease-out;
          }
        `}</style>
      </div>
    </article>
  );
}
