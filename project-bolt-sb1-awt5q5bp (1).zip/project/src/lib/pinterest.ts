export const buildPinterestEmbeds = () => {
  if (!window.PinUtils) {
    console.warn('Pinterest PinUtils not loaded yet');
    return false;
  }

  try {
    window.PinUtils.build();
    return true;
  } catch (error) {
    console.error('Failed to build Pinterest embeds:', error);
    return false;
  }
};

export const waitForPinterestAndBuild = (maxAttempts = 10, delay = 300): Promise<boolean> => {
  return new Promise((resolve) => {
    let attempts = 0;

    const tryBuild = () => {
      attempts++;

      if (buildPinterestEmbeds()) {
        resolve(true);
        return;
      }

      if (attempts >= maxAttempts) {
        console.warn('Pinterest script failed to load after max attempts');
        resolve(false);
        return;
      }

      setTimeout(tryBuild, delay);
    };

    tryBuild();
  });
};

export const resolvePinItUrl = async (url: string): Promise<string> => {
  if (!url.includes('pin.it')) {
    return url;
  }

  return url;
};
